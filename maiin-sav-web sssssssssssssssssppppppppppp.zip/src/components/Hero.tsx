import type { CSSProperties } from "react";
import { Count, FadeImg, Icon, IosBubbles, RotBadge } from "./Shared";
import { CONTACT_INFO, IMG, STATS, TICKER } from "../data";

const d = (s: string) => ({ "--d": s }) as CSSProperties;

export default function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-ink-950 pb-20 pt-32 md:pt-40">
      {/* ambient layers */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(60% 55% at 78% 18%, rgba(47,114,219,0.30), transparent 60%), radial-gradient(50% 45% at 12% 85%, rgba(247,148,29,0.16), transparent 60%), linear-gradient(180deg, #050f1e 0%, #0a1b33 55%, #0f2848 100%)",
        }}
        aria-hidden="true"
      />
      <div className="pattern-dots absolute inset-0 opacity-50" aria-hidden="true" />
      <IosBubbles count={3} />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-10 top-16 select-none font-display text-[20vw] font-black leading-none text-outline"
      >
        S.A.V.
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 md:px-6">
        <div className="grid items-center gap-14 lg:grid-cols-12">
          {/* left */}
          <div className="lg:col-span-6">
            <div className="flex flex-wrap items-center gap-3 hero-in" style={d("0.05s")}>
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/8 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.18em] text-royal-300 backdrop-blur">
                <Icon name="grad" className="h-3.5 w-3.5" />
                Nursery · LKG · UKG · Class I – X
              </span>
              <span className="inline-flex items-center gap-2 rounded-full border border-saffron-400/40 bg-saffron-500/15 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.18em] text-saffron-400">
                <span className="relative flex h-2 w-2">
                  <span className="glow-pulse absolute inline-flex h-full w-full rounded-full bg-saffron-400" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-saffron-400" />
                </span>
                Admissions Open 2026-27
              </span>
            </div>

            <h1 className="mt-6 font-display text-[44px] font-semibold leading-[1.02] tracking-tight text-white sm:text-6xl xl:text-[76px] hero-in" style={d("0.15s")}>
              Shantiniketan
              <span className="mt-1 block italic text-saffron-400">
                Adarsh Vidyalaya
                <span className="ml-3 align-super font-sans text-base font-bold not-italic tracking-widest text-cream-100/50">(S.A.V.)</span>
              </span>
            </h1>

            <p className="mt-6 max-w-xl text-base leading-relaxed text-ink-100/85 md:text-lg hero-in" style={d("0.25s")}>
              A trusted school in <strong className="font-bold text-white">Raxaul, East Champaran</strong> — where young minds grow with
              confidence, discipline and joy, from their very first day of learning to Class X.
            </p>

            <div className="mt-5 inline-flex items-center gap-3 rounded-2xl border border-gold-400/30 bg-white/6 px-5 py-3 backdrop-blur hero-in" style={d("0.32s")}>
              <Icon name="trophy" className="h-6 w-6 shrink-0 text-gold-400" />
              <p className="text-sm font-bold text-cream-100/90">
                Best School Award <span className="text-gold-400">2025-2026</span> · East Champaran District, Bihar
              </p>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-4 hero-in" style={d("0.4s")}>
              <a
                href="#admissions"
                className="shine group inline-flex items-center gap-2.5 rounded-full bg-saffron-500 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-ink-950 shadow-xl shadow-saffron-500/30 transition-all duration-300 hover:-translate-y-1 hover:bg-saffron-400"
              >
                Apply for Admission
                <Icon name="arrow" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
              <a
                href="#facilities"
                className="inline-flex items-center gap-2.5 rounded-full border border-white/25 bg-white/5 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-white backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:bg-white/15"
              >
                Explore Campus
              </a>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-x-7 gap-y-3 text-sm font-semibold text-ink-100/75 hero-in" style={d("0.5s")}>
              <a href={`tel:${CONTACT_INFO.phones[0].replace(/\s/g, "")}`} className="flex items-center gap-2 transition-colors hover:text-saffron-400">
                <Icon name="phone" className="h-4 w-4 text-saffron-400" />
                {CONTACT_INFO.phones[0]}
              </a>
              <span className="flex items-center gap-2">
                <Icon name="pin" className="h-4 w-4 text-saffron-400" />
                Main Road, Laxmipur, Raxaul
              </span>
            </div>
          </div>

          {/* right composition */}
          <div className="hero-in lg:col-span-6" style={d("0.3s")}>
            <div className="relative mx-auto max-w-[560px]">
              <div className="absolute -inset-8 hidden rounded-full bg-royal-500/20 blur-3xl md:block" aria-hidden="true" />

              <div className="kenburns relative overflow-hidden rounded-[30px] border border-white/15 shadow-2xl shadow-ink-950/70">
                <FadeImg
                  src={IMG.campus}
                  alt="Shantiniketan Adarsh Vidyalaya campus building, Raxaul"
                  className="aspect-[4/3] w-full object-cover"
                  eager
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/50 via-transparent to-transparent" aria-hidden="true" />
                <div className="glass-dark absolute bottom-4 left-4 flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold text-white">
                  <Icon name="pin" className="h-4 w-4 text-saffron-400" />
                  Raxaul · East Champaran, Bihar
                </div>
              </div>

              <div className="absolute -left-8 -top-10 hidden text-saffron-400 drop-shadow-xl sm:block">
                <RotBadge text="BEST SCHOOL AWARD · 2025-26 · S.A.V. RAXAUL · " className="h-28 w-28" icon="trophy" />
              </div>

              <div className="absolute -right-3 -top-5 sm:-right-6 glass rounded-2xl px-5 py-3.5 shadow-2xl">
                <p className="font-display text-2xl font-bold text-royal-700">
                  Nur <span className="text-saffron-500">→</span> X
                </p>
                <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-ink-900/55">Complete Journey</p>
              </div>

              <div className="absolute -bottom-9 -left-4 flex items-center gap-3 glass rounded-2xl p-3 pr-6 shadow-2xl sm:-left-8">
                <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl">
                  <FadeImg src={IMG.classroom} alt="Smart classroom at S.A.V." className="h-full w-full object-cover" />
                </div>
                <div>
                  <p className="text-sm font-extrabold text-ink-900">Smart Classrooms</p>
                  <p className="text-xs font-semibold text-ink-900/55">Modern learning spaces</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* stats */}
        <div className="mt-20 hero-in" style={d("0.55s")}>
          <div className="glass-dark grid grid-cols-2 gap-y-8 rounded-3xl px-4 py-8 md:grid-cols-4 md:py-10">
            {STATS.map((s, i) => (
              <div
                key={s.label}
                className={`px-4 text-center ${i > 0 ? "md:border-l md:border-white/10" : ""}`}
              >
                <p className="font-display text-4xl font-bold text-saffron-400 md:text-5xl">
                  <Count to={s.value} suffix={s.suffix} />
                </p>
                <p className="mt-2 text-sm font-extrabold uppercase tracking-wider text-white">{s.label}</p>
                <p className="text-xs font-semibold text-ink-100/60">{s.note}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Swipeable announcements do not run an animation while the page scrolls. */}
      <div className="relative z-10 mt-16 -rotate-[1.1deg] scale-[1.02]">
        <div className="marquee border-y-2 border-ink-950/25 bg-saffron-500 py-3.5 text-ink-950 shadow-xl shadow-ink-950/30" tabIndex={0} aria-label="School announcements; scroll sideways to read more">
          <div className="marquee-track">
            {TICKER.map((t, i) => (
              <span key={i} className="flex items-center gap-3 whitespace-nowrap px-7 text-[13px] font-extrabold uppercase tracking-[0.14em]">
                <Icon name="spark" className="h-4 w-4 shrink-0" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
