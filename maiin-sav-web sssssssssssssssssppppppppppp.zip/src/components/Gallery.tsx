import { useEffect, useRef, useState, type ChangeEvent, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { FadeImg, Icon, SectionHead } from "./Shared";
import { fileToDataURL } from "./PhotoSlot";
import { FEATURED_GALLERY, GALLERY } from "../data";

const storageKey = (id: string) => `sav-gallery-${id}`;

export default function Gallery() {
  const [uploaded, setUploaded] = useState<Record<string, string>>({});
  const [published, setPublished] = useState<Set<string>>(new Set());
  const [uploadError, setUploadError] = useState("");
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const saved: Record<string, string> = {};
    for (const item of FEATURED_GALLERY) {
      try {
        const photo = localStorage.getItem(storageKey(item.id));
        if (photo) saved[item.id] = photo;
      } catch {
        // Private browsing can disable storage; the published gallery still works.
      }
    }
    setUploaded(saved);

    const controller = new AbortController();
    const checkPhotos = async () => {
      const available = await Promise.all(
        FEATURED_GALLERY.map(async (item) => {
          try {
            const response = await fetch(item.img, { method: "HEAD", signal: controller.signal });
            return response.ok && response.headers.get("content-type")?.startsWith("image/") ? item.id : null;
          } catch {
            return null;
          }
        })
      );
      if (!controller.signal.aborted) {
        setPublished(new Set(available.filter((id): id is string => id !== null)));
      }
    };
    void checkPhotos();
    return () => controller.abort();
  }, []);

  const photos = [
    ...FEATURED_GALLERY.filter((item) => uploaded[item.id] || published.has(item.id)).map((item) => ({
      img: uploaded[item.id] || item.img,
      caption: item.caption,
    })),
    ...GALLERY,
  ];
  const selected = openIdx === null ? null : photos[openIdx] ?? null;

  useEffect(() => {
    if (openIdx === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpenIdx(null);
      if (event.key === "ArrowRight") setOpenIdx((index) => index === null ? null : (index + 1) % photos.length);
      if (event.key === "ArrowLeft") setOpenIdx((index) => index === null ? null : (index - 1 + photos.length) % photos.length);
    };
    closeRef.current?.focus({ preventScroll: true });
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIdx !== null, photos.length]);

  const onUpload = async (event: ChangeEvent<HTMLInputElement>, id: string) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    try {
      const data = await fileToDataURL(file);
      localStorage.setItem(storageKey(id), data);
      setUploaded((previous) => ({ ...previous, [id]: data }));
      setUploadError("");
    } catch {
      setUploadError("The photo could not be saved on this device. Try a smaller JPG or PNG file.");
    }
  };

  return (
    <section id="gallery" className="relative overflow-hidden bg-cream-100/60 py-24 md:py-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-8 bottom-0 select-none font-display text-[15vw] font-black leading-none text-outline-dark"
      >
        MOMENTS
      </div>

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead
          overline="Gallery"
          icon="star"
          num="05"
          title={
            <>
              Life at S.A.V. <span className="italic text-royal-600">in Pictures</span>
            </>
          }
          sub="Classrooms, labs, sports days and celebrations - a glimpse of the everyday magic on our campus."
        />

        <p className="mb-7 text-sm font-semibold text-ink-900/55">School life, one moment at a time. Published photos are open to everyone.</p>

        <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 md:gap-5">
          {photos.map((photo, index) => (
            <button
              key={photo.caption}
              type="button"
              onClick={() => setOpenIdx(index)}
              data-reveal="zoom"
              style={{ "--rd": `${(index % 3) * 0.06}s` } as CSSProperties}
              className="group relative aspect-[4/3] w-full overflow-hidden rounded-xl bg-ink-100 shadow-sm transition-shadow hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-royal-600 md:rounded-2xl"
              aria-label={`Open photo: ${photo.caption}`}
            >
              <FadeImg src={photo.img} alt={photo.caption} className="absolute inset-0 h-full w-full object-cover" />
              <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink-950/85 to-transparent px-3 pb-3 pt-8 text-left text-xs font-bold text-white sm:px-4 sm:pb-4 sm:text-sm">
                {photo.caption}
              </span>
            </button>
          ))}
        </div>

        <div className="mt-8 border-t border-ink-900/15 pt-6">
          <p className="font-display text-xl font-semibold text-ink-900">Preview your school photos</p>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-900/65">
            No login required. Choose the classroom or outdoor group photo to preview it on this device.
            To show it to everyone, add the file to public/images and redeploy the site.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            {FEATURED_GALLERY.map((item) => (
              <label
                key={item.id}
                className="inline-flex min-h-11 cursor-pointer items-center gap-2 rounded-full border border-royal-600/20 bg-white px-4 py-2 text-sm font-bold text-royal-700 transition-colors hover:bg-royal-100 focus-within:ring-2 focus-within:ring-royal-500"
              >
                <Icon name="plus" className="h-4 w-4" />
                {uploaded[item.id] ? "Replace" : "Add"} {item.id === "classroom-group" ? "classroom photo" : "outdoor group photo"}
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="sr-only"
                  onChange={(event) => void onUpload(event, item.id)}
                  aria-label={`Upload ${item.caption}`}
                />
              </label>
            ))}
          </div>
          {uploadError && <p role="alert" className="mt-3 text-sm font-bold text-saffron-600">{uploadError}</p>}
        </div>
      </div>

      {selected && createPortal(
        <div
          className="lightbox-in fixed inset-0 z-[200] flex items-center justify-center overflow-hidden bg-ink-950/95 p-4 overscroll-contain [touch-action:none] md:p-10"
          onClick={(event) => {
            if (event.target === event.currentTarget) setOpenIdx(null);
          }}
          role="dialog"
          aria-modal="true"
          aria-label={selected.caption}
        >
          <button
            ref={closeRef}
            type="button"
            className="glass-dark absolute right-4 top-4 z-10 flex min-h-12 min-w-12 items-center justify-center rounded-full text-white md:right-6 md:top-6"
            onClick={() => setOpenIdx(null)}
            aria-label="Close"
          >
            <Icon name="close" className="h-5 w-5" />
          </button>
          <button
            type="button"
            className="glass-dark absolute left-2 top-1/2 z-10 flex min-h-12 min-w-12 -translate-y-1/2 items-center justify-center rounded-full text-white md:left-6"
            onClick={(event) => {
              event.stopPropagation();
              setOpenIdx((index) => index === null ? null : (index - 1 + photos.length) % photos.length);
            }}
            aria-label="Previous photo"
          >
            <Icon name="chevron" className="h-5 w-5 rotate-90" />
          </button>
          <figure className="max-h-full max-w-5xl cursor-zoom-out" onClick={() => setOpenIdx(null)}>
            <img src={selected.img} alt={selected.caption} className="max-h-[78vh] w-auto rounded-2xl border-2 border-white/20 object-contain shadow-2xl" />
            <figcaption className="mt-4 flex flex-wrap items-center justify-center gap-2 text-center text-sm font-bold text-white">
              {selected.caption} <span className="text-white/50">- {(openIdx ?? 0) + 1} / {photos.length} - Tap to close</span>
            </figcaption>
          </figure>
          <button
            type="button"
            className="glass-dark absolute right-2 top-1/2 z-10 flex min-h-12 min-w-12 -translate-y-1/2 items-center justify-center rounded-full text-white md:right-6"
            onClick={(event) => {
              event.stopPropagation();
              setOpenIdx((index) => index === null ? null : (index + 1) % photos.length);
            }}
            aria-label="Next photo"
          >
            <Icon name="chevron" className="h-5 w-5 -rotate-90" />
          </button>
        </div>,
        document.body
      )}
    </section>
  );
}