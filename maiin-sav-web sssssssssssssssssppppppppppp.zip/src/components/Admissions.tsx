import type { CSSProperties } from "react";
import { Icon, IosBubbles, SectionHead } from "./Shared";
import { CONTACT_INFO, DOCS, ELIGIBILITY, STEPS } from "../data";

export default function Admissions() {
  return (
    <section id="admissions" className="relative overflow-hidden py-24 md:py-28">
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(50% 45% at 85% 15%, rgba(247,148,29,0.2), transparent 60%), linear-gradient(160deg, #16345C 0%, #0F2848 45%, #0A1B33 100%)",
        }}
        aria-hidden="true"
      />
      <div className="pattern-dots absolute inset-0 opacity-40" aria-hidden="true" />
      <IosBubbles count={3} />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-8 bottom-4 select-none font-display text-[14vw] font-black leading-none text-outline"
      >
        ADMISSION
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead
          overline="Admissions · Session 2026-27"
          icon="grad"
          num="07"
          light
          title={
            <>
              Get Admission to Make Your Child's <span className="italic text-saffron-400">Future Successful</span>
            </>
          }
          sub="A simple, friendly admission process — from your first enquiry to the very first day at school."
        />

        {/* steps */}
        <div className="relative">
          <div className="absolute left-[10%] right-[10%] top-8 hidden border-t-2 border-dashed border-white/20 md:block" aria-hidden="true" />
          <div className="grid gap-8 md:grid-cols-5 md:gap-4">
            {STEPS.map((s, i) => (
              <div
                key={s.title}
                className="relative text-center"
                data-reveal
                style={{ "--rd": `${i * 0.1}s` } as CSSProperties}
              >
                <div className="relative mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-white/20 bg-ink-900/70 text-saffron-400 shadow-xl shadow-ink-950/40 backdrop-blur transition-transform duration-300 hover:scale-110">
                  <Icon name={s.icon} className="h-7 w-7" />
                  <span className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-saffron-500 text-[11px] font-extrabold text-ink-950">
                    {i + 1}
                  </span>
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold text-white">{s.title}</h3>
                <p className="mx-auto mt-1.5 max-w-[180px] text-[13px] leading-relaxed text-ink-100/65">{s.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* eligibility + documents */}
        <div className="mt-16 grid gap-6 lg:grid-cols-2">
          <div className="glass-dark rounded-3xl p-7" data-reveal="left">
            <h3 className="flex items-center gap-3 font-display text-2xl font-semibold text-white">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-saffron-500/20 text-saffron-400">
                <Icon name="doc" className="h-5 w-5" />
              </span>
              Eligibility
            </h3>
            <div className="mt-5 divide-y divide-white/10">
              {ELIGIBILITY.map((e) => (
                <div key={e.cls} className="flex items-center justify-between gap-4 py-3.5">
                  <span className="text-sm font-extrabold text-white">{e.cls}</span>
                  <span className="h-px flex-1 bg-white/10" aria-hidden="true" />
                  <span className="text-sm font-semibold text-ink-100/70">{e.age}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-dark rounded-3xl p-7" data-reveal="right">
            <h3 className="flex items-center gap-3 font-display text-2xl font-semibold text-white">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-saffron-500/20 text-saffron-400">
                <Icon name="check" className="h-5 w-5" />
              </span>
              Documents Required
            </h3>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {DOCS.map((doc, i) => (
                <li
                  key={doc}
                  className="flex items-center gap-3 rounded-xl border border-white/12 bg-white/6 px-4 py-3 text-sm font-bold text-cream-100/90 transition-colors duration-300 hover:border-saffron-400/40"
                  data-reveal
                  style={{ "--rd": `${i * 0.06}s` } as CSSProperties}
                >
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-saffron-500/20 text-saffron-400">
                    <Icon name="check" className="h-3.5 w-3.5" />
                  </span>
                  {doc}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* CTA */}
        <div className="glass-dark relative mt-14 overflow-hidden rounded-3xl p-8 md:p-10" data-reveal="fade">
          <div
            className="absolute inset-0"
            style={{ background: "linear-gradient(110deg, rgba(247,148,29,0.16), rgba(47,114,219,0.14))" }}
            aria-hidden="true"
          />
          <div className="relative flex flex-wrap items-center justify-between gap-6">
            <div className="max-w-xl">
              <h3 className="font-display text-2xl font-semibold text-white md:text-3xl">
                Seats are filling fast for the <span className="italic text-saffron-400">2026-27 session</span>
              </h3>
              <p className="mt-2 text-[15px] leading-relaxed text-ink-100/75">
                Give your child the head start they deserve. Our admission team is ready to guide you at every step.
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <a
                href={`tel:${CONTACT_INFO.phones[0].replace(/\s/g, "")}`}
                className="shine group inline-flex items-center gap-2.5 rounded-full bg-saffron-500 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-ink-950 shadow-xl shadow-saffron-500/30 transition-all duration-300 hover:-translate-y-1 hover:bg-saffron-400"
              >
                <Icon name="phone" className="h-4 w-4" />
                Call the Office
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2.5 rounded-full border border-white/25 bg-white/5 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-white backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:bg-white/15"
              >
                Send Enquiry
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
