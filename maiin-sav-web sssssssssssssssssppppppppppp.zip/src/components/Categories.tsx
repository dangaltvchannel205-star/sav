import type { CSSProperties } from "react";
import { FadeImg, Icon, SectionHead } from "./Shared";
import { CATEGORIES } from "../data";

export default function Categories() {
  return (
    <section id="categories" className="relative overflow-hidden bg-cream-100/70 py-20 md:py-24">
      <div className="pattern-dots-dark absolute inset-0 opacity-40" aria-hidden="true" />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-10 top-4 select-none font-display text-[14vw] font-black leading-none text-outline-dark"
      >
        EXPLORE
      </div>

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead
          center
          overline="Categories"
          icon="grid"
          title={
            <>
              Explore Our School <span className="italic text-royal-600">Category Wise</span>
            </>
          }
          sub="Everything about Shantiniketan Adarsh Vidyalaya, neatly organised — pick a category and jump straight to it."
        />

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((c, i) => (
            <a
              key={c.title}
              href={c.href}
              className="glass card-lift group relative flex items-center gap-4 overflow-hidden rounded-3xl p-5"
              data-reveal
              style={{ "--rd": `${(i % 3) * 0.08}s` } as CSSProperties}
            >
              <span
                className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${c.tone} transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110`}
              >
                <Icon name={c.icon} className="h-7 w-7" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-baseline gap-2">
                  <span className="font-display text-sm font-black tracking-widest text-ink-900/30">{c.num}</span>
                  <span className="truncate font-display text-lg font-semibold text-ink-900">{c.title}</span>
                </span>
                <span className="mt-1 block text-[13px] leading-relaxed text-ink-900/60">{c.desc}</span>
              </span>
              <span className="relative shrink-0">
                <span className="block h-14 w-20 overflow-hidden rounded-xl">
                  <FadeImg src={c.img} alt={c.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                </span>
                <span className="absolute -right-1.5 -top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-saffron-500 text-ink-950 shadow-md transition-transform duration-300 group-hover:rotate-90">
                  <Icon name="arrow" className="h-3 w-3" />
                </span>
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
