import type { CSSProperties } from "react";
import { FadeImg, Icon, SectionHead } from "./Shared";
import { AMENITIES, CAMPUS_CARDS, FACILITIES } from "../data";

export default function Campus() {
  return (
    <section id="facilities" className="relative overflow-hidden bg-cream-50 py-24 md:py-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-10 bottom-8 select-none font-display text-[15vw] font-black leading-none text-outline-dark"
      >
        CAMPUS
      </div>

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead
          overline="Facilities"
          icon="building"
          num="03"
          title={
            <>
              Explore Our <span className="italic text-royal-600">Beautiful Campus</span>
            </>
          }
          sub="Shantiniketan Adarsh Vidyalaya provides a safe, modern and inspiring environment where students grow with confidence, discipline and joy."
        />

        {/* three signature campus cards */}
        <div className="grid gap-7 lg:grid-cols-3">
          {CAMPUS_CARDS.map((c, i) => (
            <article
              key={c.title}
              className="group card-lift overflow-hidden rounded-3xl border border-ink-900/8 bg-white shadow-lg shadow-ink-900/8"
              data-reveal
              style={{ "--rd": `${i * 0.12}s` } as CSSProperties}
            >
              <div className="kb-hover relative overflow-hidden">
                <FadeImg src={c.img} alt={c.title} className="aspect-[16/10] w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/35 to-transparent" aria-hidden="true" />
                <span className="absolute left-4 top-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-saffron-500 text-ink-950 shadow-lg transition-transform duration-500 group-hover:rotate-6 group-hover:scale-110">
                  <Icon name={c.icon} className="h-6 w-6" />
                </span>
              </div>
              <div className="p-6">
                <h3 className="font-display text-2xl font-semibold text-ink-900">{c.title}</h3>
                <p className="mt-2.5 text-[15px] leading-relaxed text-ink-900/65">{c.text}</p>
              </div>
            </article>
          ))}
        </div>

        {/* facility tiles */}
        <div className="mt-16">
          <div className="mb-8 flex items-end justify-between gap-4" data-reveal="fade">
            <h3 className="font-display text-3xl font-semibold text-ink-900">
              Spaces that <span className="italic text-royal-600">shape learning</span>
            </h3>
            <p className="hidden text-sm font-semibold text-ink-900/50 md:block">Labs · Library · Classrooms · Activity areas</p>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {FACILITIES.map((f, i) => (
              <a
                key={f.title}
                href="#gallery"
                className="shine group relative block overflow-hidden rounded-3xl shadow-lg shadow-ink-900/10"
                data-reveal
                style={{ "--rd": `${(i % 3) * 0.1}s` } as CSSProperties}
              >
                <div className="kb-hover h-64 overflow-hidden">
                  <FadeImg src={f.img} alt={f.title} className="h-full w-full object-cover" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/90 via-ink-950/35 to-transparent" aria-hidden="true" />
                <div className="absolute inset-x-0 bottom-0 flex items-end gap-3 p-5">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/15 text-saffron-400 backdrop-blur transition-transform duration-500 group-hover:-rotate-6">
                    <Icon name={f.icon} className="h-5.5 w-5.5" />
                  </span>
                  <span>
                    <span className="block font-display text-lg font-bold leading-tight text-white">{f.title}</span>
                    <span className="mt-1 block max-h-0 overflow-hidden text-[13px] leading-snug text-cream-100/80 opacity-0 transition-all duration-500 group-hover:max-h-16 group-hover:opacity-100">
                      {f.text}
                    </span>
                  </span>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* amenities */}
        <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {AMENITIES.map((a, i) => (
            <div
              key={a.title}
              className="glass group flex flex-col items-center gap-3 rounded-2xl px-3 py-5 text-center transition-transform duration-300 hover:-translate-y-1"
              data-reveal
              style={{ "--rd": `${i * 0.06}s` } as CSSProperties}
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-royal-100 text-royal-700 transition-all duration-300 group-hover:bg-saffron-100 group-hover:text-saffron-600">
                <Icon name={a.icon} className="h-5.5 w-5.5" />
              </span>
              <span className="text-[12.5px] font-extrabold leading-tight text-ink-900">{a.title}</span>
            </div>
          ))}
        </div>

        {/* visit CTA */}
        <div
          className="glass relative mt-14 overflow-hidden rounded-3xl p-8 md:p-10"
          data-reveal="fade"
        >
          <div
            className="absolute inset-0"
            style={{ background: "linear-gradient(110deg, rgba(47,114,219,0.12), rgba(247,148,29,0.12))" }}
            aria-hidden="true"
          />
          <div className="relative flex flex-wrap items-center justify-between gap-6">
            <div className="max-w-xl">
              <h3 className="font-display text-2xl font-semibold text-ink-900 md:text-3xl">
                See it all for yourself — <span className="italic text-royal-600">visit our campus</span>
              </h3>
              <p className="mt-2 text-[15px] leading-relaxed text-ink-900/65">
                Walk the corridors, meet our teachers and let your child experience the S.A.V. difference in person.
              </p>
            </div>
            <a
              href="#contact"
              className="shine group inline-flex items-center gap-2.5 rounded-full bg-ink-900 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-white shadow-xl shadow-ink-900/25 transition-all duration-300 hover:-translate-y-1 hover:bg-royal-600"
            >
              Plan a Visit
              <Icon name="arrow" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
