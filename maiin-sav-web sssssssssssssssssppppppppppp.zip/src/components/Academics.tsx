import { useState, type CSSProperties } from "react";
import { Icon, SectionHead } from "./Shared";
import { CLASSES, PEDAGOGY, STAGES, SUBJECTS } from "../data";

const TONE = {
  saffron: { chip: "bg-saffron-100 text-saffron-600", pill: "bg-saffron-100/70 text-saffron-600 border border-saffron-400/30" },
  royal: { chip: "bg-royal-100 text-royal-700", pill: "bg-royal-100/70 text-royal-700 border border-royal-500/25" },
  leaf: { chip: "bg-leaf-100 text-leaf-600", pill: "bg-leaf-100/70 text-leaf-600 border border-leaf-500/25" },
};

export default function Academics() {
  const [activeCls, setActiveCls] = useState(CLASSES[0]);

  return (
    <section id="academics" className="relative overflow-hidden bg-royal-100/45 py-24 md:py-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-6 bottom-0 select-none font-display text-[15vw] font-black leading-none text-outline-dark"
      >
        LEARN
      </div>

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead
          overline="Academics · Nursery to Class X"
          icon="grad"
          num="02"
          title={
            <>
              A Learning Journey from <span className="italic text-royal-600">First Steps</span> to Board Success
            </>
          }
          sub="A structured curriculum, modern teaching and caring mentorship at every stage — so each child grows at their own pace and is never left behind."
        />

        {/* stages */}
        <div className="grid gap-6 md:grid-cols-3">
          {STAGES.map((s, i) => {
            const tone = TONE[s.color as keyof typeof TONE];
            return (
              <article
                key={s.stage}
                className="glass card-lift group relative overflow-hidden rounded-3xl p-7"
                data-reveal
                style={{ "--rd": `${i * 0.12}s` } as CSSProperties}
              >
                <div
                  className="absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-25 blur-2xl transition-opacity duration-500 group-hover:opacity-50"
                  style={{
                    background: s.color === "saffron" ? "#F7941D" : s.color === "royal" ? "#2F72DB" : "#27A35B",
                  }}
                  aria-hidden="true"
                />
                <div className="flex items-start justify-between">
                  <span className={`inline-flex h-14 w-14 items-center justify-center rounded-2xl ${tone.chip}`}>
                    <Icon name={s.icon} className="h-7 w-7" />
                  </span>
                  <span className="rounded-full bg-white/80 px-3 py-1.5 text-[11px] font-extrabold uppercase tracking-wider text-ink-900/60">
                    {s.age}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-2xl font-semibold text-ink-900">{s.stage}</h3>
                <p className="mt-1 text-sm font-extrabold uppercase tracking-wider text-royal-700">{s.classes}</p>
                <p className="mt-3 text-[15px] leading-relaxed text-ink-900/65">{s.desc}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {s.subjects.map((x) => (
                    <span key={x} className={`rounded-full px-3 py-1 text-[11px] font-bold ${tone.pill}`}>
                      {x}
                    </span>
                  ))}
                </div>
              </article>
            );
          })}
        </div>

        {/* class rail */}
        <div className="glass mt-10 rounded-3xl p-6 md:p-7" data-reveal="fade">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="font-display text-xl font-semibold text-ink-900">
              Our Classes <span className="text-saffron-500">·</span>{" "}
              <span className="rounded-full bg-royal-600 px-3 py-1 text-sm font-extrabold text-white">{activeCls}</span>
            </p>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-ink-900/45">Scroll &amp; tap a class</p>
          </div>
          <div className="mt-4 flex gap-3 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {CLASSES.map((c) => (
              <button
                key={c}
                onClick={() => setActiveCls(c)}
                className={`shrink-0 rounded-full border px-5 py-2.5 text-sm font-extrabold transition-all duration-300 ${
                  activeCls === c
                    ? "-translate-y-0.5 border-royal-600 bg-royal-600 text-white shadow-lg shadow-royal-600/30"
                    : "border-ink-900/10 bg-white/85 text-ink-800 hover:-translate-y-0.5 hover:border-royal-500 hover:text-royal-700"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-x-8 gap-y-2 border-t border-ink-900/8 pt-4 text-sm font-bold text-ink-900/60">
            <span className="flex items-center gap-2">
              <Icon name="book" className="h-4 w-4 text-royal-700" /> Medium of Instruction: English
            </span>
            <span className="flex items-center gap-2">
              <Icon name="doc" className="h-4 w-4 text-royal-700" /> Board: Bihar (BSEB)
            </span>
            <span className="flex items-center gap-2">
              <Icon name="clock" className="h-4 w-4 text-royal-700" /> Timings: 8:00 AM – 2:00 PM
            </span>
          </div>
        </div>

        {/* subjects */}
        <div className="mt-20">
          <div className="mb-8 flex items-end justify-between gap-4" data-reveal="fade">
            <h3 className="font-display text-3xl font-semibold text-ink-900">
              Core Subjects <span className="italic text-royal-600">&amp; More</span>
            </h3>
            <p className="hidden text-sm font-semibold text-ink-900/50 md:block">A balanced mix of academics, skills &amp; co-curriculars</p>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {SUBJECTS.map((s, i) => (
              <div
                key={s.name}
                className="glass group flex items-center gap-3 rounded-2xl px-4 py-3.5 transition-all duration-300 hover:-translate-y-1"
                data-reveal
                style={{ "--rd": `${(i % 5) * 0.07}s` } as CSSProperties}
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-royal-100 text-royal-700 transition-colors duration-300 group-hover:bg-saffron-100 group-hover:text-saffron-600">
                  <Icon name={s.icon} className="h-5 w-5" />
                </span>
                <span className="text-sm font-extrabold leading-tight text-ink-900">{s.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* pedagogy */}
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {PEDAGOGY.map((p, i) => (
            <div
              key={p.title}
              className="card-lift rounded-3xl border border-ink-900/8 bg-white/80 p-6"
              data-reveal
              style={{ "--rd": `${i * 0.1}s` } as CSSProperties}
            >
              <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-ink-900 text-saffron-400">
                <Icon name={p.icon} className="h-5.5 w-5.5" />
              </span>
              <h4 className="mt-4 font-display text-lg font-semibold leading-snug text-ink-900">{p.title}</h4>
              <p className="mt-2 text-sm leading-relaxed text-ink-900/60">{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
