import { Crest, FadeImg, Icon, SectionHead } from "./Shared";
import { PhotoSlot } from "./PhotoSlot";
import { ABOUT, BOARD, PRINCIPAL, TESTIMONIALS, VP, IMG } from "../data";

const MISION = [
  {
    icon: "target",
    title: "Our Mission",
    text: "To provide balanced learning with knowledge and character, shaping confident, caring and capable citizens.",
    tone: "bg-royal-100 text-royal-700",
  },
  {
    icon: "eye",
    title: "Our Vision",
    text: "To be East Champaran's most trusted school, where every child discovers the joy of lifelong learning.",
    tone: "bg-saffron-100 text-saffron-600",
  },
  {
    icon: "heart",
    title: "Our Values",
    text: "Discipline · Honesty · Respect · Creativity · Service — woven into every classroom and corridor.",
    tone: "bg-leaf-100 text-leaf-600",
  },
];

function LeaderRow({
  person,
  flip = false,
  message = false,
}: {
  person: { name: string; role: string; slotId: string; initials: string; img?: string; message: string };
  flip?: boolean;
  message?: boolean;
}) {
  return (
    <div className={`grid items-center gap-8 lg:grid-cols-12 ${flip ? "" : ""}`}>
      <div data-reveal={flip ? "right" : "left"} className={`relative lg:col-span-5 ${flip ? "lg:order-2" : ""}`}>
        <div className="absolute -inset-4 rounded-[36px] bg-royal-500/15 blur-2xl" aria-hidden="true" />
        <div className="relative overflow-hidden rounded-[28px] border-4 border-white bg-royal-100 shadow-2xl shadow-ink-900/25">
          <div className="aspect-[4/5] w-full">
            <PhotoSlot id={person.slotId} name={person.name} initials={person.initials} defaultSrc={person.img} />
          </div>
          <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink-950/80 to-transparent p-5 pt-14">
            <p className="font-display text-2xl font-bold text-white">{person.name}</p>
            <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-saffron-400">{person.role}</p>
          </div>
        </div>
      </div>
      <div data-reveal={flip ? "left" : "right"} className={`lg:col-span-7 ${flip ? "lg:order-1" : ""}`}>
        <svg viewBox="0 0 48 32" className="h-9 w-14 text-saffron-400" fill="currentColor" aria-hidden="true">
          <path d="M0 32V20C0 9 6 2 16 0l2.5 5C11.5 7.5 8 11.5 7.5 16H16v16H0zm32 0V20C32 9 38 2 48 0l-1.5 5C34 7.5 30.5 11.5 30 16H40v16H32z" opacity="0.9" />
        </svg>
        <p className={`mt-4 font-display leading-snug text-ink-900 ${message ? "text-2xl md:text-[27px] font-medium" : "text-xl md:text-2xl font-medium"}`}>
          “{person.message}”
        </p>
        <div className="mt-6 flex items-center gap-4">
          <Crest className="h-11 w-11" />
          <div>
            <p className="text-base font-extrabold text-ink-900">{person.name}</p>
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-royal-700">{person.role}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden bg-cream-50 py-24 md:py-28">
      <div className="pattern-dots-dark absolute inset-0 opacity-50" aria-hidden="true" />
      <div aria-hidden="true" className="pointer-events-none absolute -left-8 top-10 select-none font-display text-[16vw] font-black leading-none text-outline-dark">
        TRUST
      </div>

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        {/* about intro */}
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div className="relative" data-reveal="left">
            <div className="kb-hover relative z-10 overflow-hidden rounded-[28px] shadow-2xl shadow-ink-900/20">
              <FadeImg src={IMG.building} alt="Shantiniketan Adarsh Vidyalaya main building" className="aspect-[4/5] w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/30 to-transparent" aria-hidden="true" />
            </div>
            <div className="absolute -bottom-8 -right-3 z-20 w-44 overflow-hidden rounded-2xl border-4 border-white shadow-2xl sm:-right-8">
              <FadeImg src={IMG.reading} alt="Students reading at S.A.V. library" className="aspect-[4/3] w-full object-cover" />
            </div>
            <div className="glass absolute -top-6 left-4 z-20 flex items-center gap-3 rounded-2xl p-3.5 pr-5 shadow-xl">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-saffron-100 text-saffron-600">
                <Icon name="trophy" className="h-6 w-6" />
              </span>
              <span>
                <span className="block text-sm font-extrabold text-ink-900">Best School Award</span>
                <span className="block text-xs font-bold text-ink-900/55">2025-26 · East Champaran</span>
              </span>
            </div>
          </div>

          <div data-reveal="right">
            <SectionHead overline="About S.A.V." icon="book" num="01" title={ABOUT.title} />
            <p className="-mt-6 text-base leading-relaxed text-ink-900/70 md:text-lg">{ABOUT.p1}</p>
            <p className="mt-4 text-base leading-relaxed text-ink-900/70 md:text-lg">{ABOUT.p2}</p>
            <ul className="mt-7 grid gap-3 sm:grid-cols-2">
              {ABOUT.points.map((p, i) => (
                <li
                  key={p}
                  className="glass flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold text-ink-800 transition-transform duration-300 hover:-translate-y-0.5"
                  data-reveal
                  style={{ "--rd": `${i * 0.08}s` } as React.CSSProperties}
                >
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-leaf-100 text-leaf-600">
                    <Icon name="check" className="h-3.5 w-3.5" />
                  </span>
                  {p}
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap items-center gap-5">
              <a
                href="#academics"
                className="shine group inline-flex items-center gap-2.5 rounded-full bg-royal-600 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-white shadow-xl shadow-royal-600/30 transition-all duration-300 hover:-translate-y-1 hover:bg-royal-500"
              >
                Explore More
                <Icon name="arrow" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
              <p className="text-sm font-semibold text-ink-900/55">
                Managed by <span className="font-extrabold text-ink-900">Shanti Seva Charitable Trust</span>
              </p>
            </div>
          </div>
        </div>

        {/* mission / vision / values */}
        <div className="mt-24 grid gap-6 md:grid-cols-3">
          {MISION.map((m, i) => (
            <div
              key={m.title}
              className="glass card-lift rounded-3xl p-7"
              data-reveal
              style={{ "--rd": `${i * 0.1}s` } as React.CSSProperties}
            >
              <span className={`inline-flex h-13 w-13 items-center justify-center rounded-2xl p-3.5 ${m.tone}`}>
                <Icon name={m.icon} className="h-6 w-6" />
              </span>
              <h3 className="mt-5 font-display text-2xl font-semibold text-ink-900">{m.title}</h3>
              <p className="mt-3 text-[15px] leading-relaxed text-ink-900/65">{m.text}</p>
            </div>
          ))}
        </div>

        {/* testimonials */}
        <div className="mt-24">
          <div className="mb-10 flex items-end justify-between gap-4" data-reveal="fade">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-ink-900/10 bg-white/70 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.22em] text-royal-700">
                <Icon name="star" className="h-3.5 w-3.5" />
                Student Voices
              </span>
              <h3 className="mt-4 font-display text-3xl font-semibold text-ink-900 md:text-4xl">What Our Students Say</h3>
            </div>
            <p className="hidden max-w-xs text-sm leading-relaxed text-ink-900/55 md:block">
              Hear from our students about their joyful learning journey and memorable moments at S.A.V.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {TESTIMONIALS.map((t, i) => (
              <figure
                key={t.name}
                className="glass card-lift flex items-start gap-5 rounded-3xl p-6"
                data-reveal
                style={{ "--rd": `${i * 0.12}s` } as React.CSSProperties}
              >
                <div className="h-16 w-16 shrink-0 overflow-hidden rounded-2xl ring-2 ring-saffron-400/60">
                  <FadeImg src={t.img} alt={t.name} className="h-full w-full object-cover" />
                </div>
                <div>
                  <blockquote className="text-[15px] leading-relaxed text-ink-900/70">“{t.text}”</blockquote>
                  <figcaption className="mt-3 text-sm font-extrabold text-ink-900">
                    {t.name} <span className="font-bold text-royal-700">· Student, S.A.V.</span>
                  </figcaption>
                </div>
              </figure>
            ))}
          </div>
        </div>

        {/* principal & vice principal */}
        <div id="leadership" className="mt-28 scroll-mt-24">
          <div className="mb-12 text-center" data-reveal="fade">
            <span className="inline-flex items-center gap-2 rounded-full border border-ink-900/10 bg-white/70 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.22em] text-royal-700">
              <Icon name="grad" className="h-3.5 w-3.5" />
              Leadership
            </span>
            <h3 className="mt-4 font-display text-3xl font-semibold text-ink-900 md:text-4xl">Principal &amp; Vice Principal</h3>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-ink-900/60 md:text-base">
              Leading the school with dedication and excellence.
            </p>
          </div>

          <div className="space-y-16 md:space-y-20">
            <LeaderRow person={PRINCIPAL} message />
            <LeaderRow person={VP} flip />
          </div>
        </div>

        {/* board of directors */}
        <div className="mt-24">
          <div className="mb-10 max-w-2xl" data-reveal="fade">
            <span className="inline-flex items-center gap-2 rounded-full border border-ink-900/10 bg-white/70 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.22em] text-royal-700">
              <Icon name="users" className="h-3.5 w-3.5" />
              Board of Directors
            </span>
            <h3 className="mt-4 font-display text-3xl font-semibold text-ink-900 md:text-4xl">The Visionary Leaders</h3>
            <p className="mt-3 text-sm leading-relaxed text-ink-900/60 md:text-base">
              Meet the guiding minds of Shantiniketan Adarsh Vidyalaya.
            </p>
          </div>
          <div className="grid gap-7 md:grid-cols-3">
            {BOARD.map((b, i) => (
              <article
                key={b.name}
                className="glass card-lift group overflow-hidden rounded-3xl"
                data-reveal
                style={{ "--rd": `${i * 0.12}s` } as React.CSSProperties}
              >
                <div className="relative overflow-hidden bg-royal-100">
                  <div className="aspect-[4/5] w-full">
                    <PhotoSlot id={b.slotId} name={b.name} initials={b.initials} />
                  </div>
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent" aria-hidden="true" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="font-display text-xl font-bold text-white">{b.name}</p>
                    <p className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-saffron-400">{b.role}</p>
                  </div>
                </div>
                <div className="border-l-2 border-saffron-400 px-5 py-4">
                  <p className="text-sm italic leading-relaxed text-ink-900/65">“{b.quote}”</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
