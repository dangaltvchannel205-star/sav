import { useEffect, useRef, useState } from "react";
import { Crest, Icon } from "./Shared";
import { CATEGORIES, NAV_LINKS } from "../data";

const EXPLORE_LINKS = [
  { label: "Home", href: "#home", icon: "building" },
  ...CATEGORIES.map(({ title, href, icon }) => ({ label: title, href, icon })),
];

export default function Nav() {
  const [open, setOpen] = useState(false);
  const exploreRef = useRef<HTMLDivElement>(null);
  const exploreButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const onOutsideClick = (event: MouseEvent) => {
      if (!exploreRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        exploreButtonRef.current?.focus();
      }
    };
    document.addEventListener("click", onOutsideClick);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("click", onOutsideClick);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-[100] border-b border-white/10 bg-ink-950/95 shadow-lg shadow-ink-950/20">
        {/* main nav */}
        <nav aria-label="Main navigation">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 md:px-6">
            <a href="#home" onClick={() => setOpen(false)} className="group flex min-w-0 items-center gap-3">
              <Crest className="h-11 w-11 transition-transform duration-500 group-hover:rotate-6 md:h-12 md:w-12" />
              <span className="min-w-0 leading-tight">
                <span className="block font-display text-lg font-semibold text-white sm:hidden">S.A.V.</span>
                <span className="hidden font-display text-[17px] font-semibold text-white sm:block md:text-lg">
                  Shantiniketan Adarsh
                </span>
                <span className="block text-[9px] font-extrabold uppercase tracking-[0.2em] text-saffron-400 sm:text-[9.5px] sm:tracking-[0.3em]">
                  <span className="sm:hidden">Raxaul</span>
                  <span className="hidden sm:inline">Vidyalaya · Raxaul</span>
                </span>
              </span>
            </a>

            <div className="hidden items-center gap-6 xl:flex">
              {NAV_LINKS.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  className="link-underline text-[13px] font-bold tracking-wide text-white/75 transition-colors duration-300 hover:text-white"
                >
                  {l.label}
                </a>
              ))}
            </div>

            <div className="flex shrink-0 items-center gap-3">
              <a
                href="#admissions"
                className="shine hidden rounded-full bg-saffron-500 px-5 py-2.5 text-sm font-extrabold text-ink-950 shadow-lg shadow-saffron-500/30 transition-all duration-300 hover:-translate-y-0.5 hover:bg-saffron-400 sm:inline-block"
              >
                Apply Now
              </a>
              <div ref={exploreRef} className="relative xl:hidden">
                <button
                  ref={exploreButtonRef}
                  type="button"
                  onClick={() => setOpen((value) => !value)}
                  aria-expanded={open}
                  aria-controls="explore-panel"
                  aria-label="Explore school sections"
                  className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/25 bg-white/10 px-3.5 py-2 text-sm font-extrabold text-white transition-colors hover:border-saffron-400/60 hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-saffron-400"
                >
                  <Icon name="compass" className={`h-5 w-5 text-saffron-400 transition-transform duration-200 ${open ? "rotate-45" : "rotate-0"}`} />
                  Explore
                  <Icon name="chevron" className={`h-3.5 w-3.5 transition-transform duration-200 ${open ? "rotate-180" : ""}`} />
                </button>

                <div
                  id="explore-panel"
                  className="explore-panel absolute right-0 top-full z-30 mt-2 max-h-[65dvh] w-[min(22rem,calc(100vw-2rem))] overflow-y-auto rounded-2xl border border-white/15 bg-ink-900 p-4 text-white shadow-2xl shadow-ink-950/50"
                  data-open={open}
                  aria-hidden={!open}
                  inert={!open}
                >
                  <p className="mb-3 px-1 font-display text-lg font-semibold text-white">Explore S.A.V.</p>
                  <div className="grid grid-cols-2 gap-2">
                    {EXPLORE_LINKS.map((link) => (
                      <a
                        key={link.href}
                        href={link.href}
                        onClick={() => setOpen(false)}
                        className="flex min-h-12 items-center gap-2 rounded-xl bg-white/5 px-3 py-2 text-[12px] font-bold leading-snug text-white/85 transition-colors hover:bg-saffron-500 hover:text-ink-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-saffron-400"
                      >
                        <Icon name={link.icon} className="h-4 w-4 shrink-0" />
                        {link.label}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </nav>
    </header>
  );
}
