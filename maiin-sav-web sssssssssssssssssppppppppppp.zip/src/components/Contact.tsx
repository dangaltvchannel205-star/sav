import { useRef, useState, type CSSProperties, type FormEvent } from "react";
import { Crest, FadeImg, Icon, IosBubbles } from "./Shared";
import { CLASSES, CONTACT_INFO, IMG, NAV_LINKS } from "../data";

const INFO = [
  { icon: "pin", label: "School Address", value: CONTACT_INFO.address },
  { icon: "phone", label: "Phone", value: CONTACT_INFO.phones.join("  ·  ") },
  { icon: "mail", label: "Email", value: CONTACT_INFO.email },
  { icon: "clock", label: "Office Hours", value: CONTACT_INFO.hours },
];

function MapCard() {
  return (
    <div className="glass-dark relative mt-14 overflow-hidden rounded-3xl" data-reveal="fade">
      <div className="relative h-64 overflow-hidden md:h-72">
        {/* stylized map */}
        <svg viewBox="0 0 800 300" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
          <rect width="800" height="300" fill="#0F2848" />
          {Array.from({ length: 16 }).map((_, i) => (
            <line key={`v${i}`} x1={i * 53} y1="0" x2={i * 53} y2="300" stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
          ))}
          {Array.from({ length: 7 }).map((_, i) => (
            <line key={`h${i}`} x1="0" y1={i * 46} x2="800" y2={i * 46} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
          ))}
          <path d="M-20 210 C 150 190, 260 120, 420 130 S 700 190, 830 150" stroke="rgba(247,148,29,0.5)" strokeWidth="7" fill="none" strokeLinecap="round" />
          <path d="M180 -20 C 210 90, 150 190, 230 320" stroke="rgba(255,255,255,0.18)" strokeWidth="5" fill="none" />
          <path d="M560 -20 C 540 100, 620 200, 590 320" stroke="rgba(255,255,255,0.14)" strokeWidth="4" fill="none" />
          <circle cx="400" cy="150" r="34" fill="rgba(247,148,29,0.14)" />
          <circle cx="400" cy="150" r="16" fill="rgba(247,148,29,0.25)" />
        </svg>
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <span className="relative flex h-12 w-12 items-center justify-center rounded-full bg-saffron-500 text-ink-950 shadow-2xl shadow-saffron-500/40">
            <Icon name="pin" className="h-6 w-6" />
          </span>
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-4 p-6">
        <div>
          <p className="text-sm font-extrabold uppercase tracking-[0.18em] text-saffron-400">Find Us</p>
          <p className="mt-1 text-base font-bold text-white">{CONTACT_INFO.address}</p>
        </div>
        <a
          href={CONTACT_INFO.mapsUrl}
          target="_blank"
          rel="noreferrer"
          className="shine group inline-flex items-center gap-2.5 rounded-full bg-white/10 px-6 py-3 text-sm font-extrabold uppercase tracking-wider text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/20"
        >
          Open in Google Maps
          <Icon name="arrow" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
        </a>
      </div>
    </div>
  );
}

function EnquiryForm() {
  type EnquiryResponse = {
    success?: boolean;
    partial?: boolean;
    reference?: string;
    emailAccepted?: boolean;
    smsAccepted?: string[];
    smsFailed?: string[];
    message?: string;
    error?: string;
  };

  const submitting = useRef(false);
  const [status, setStatus] = useState<{
    kind: "idle" | "sending" | "success" | "partial" | "error";
    text: string;
    details?: EnquiryResponse;
  }>({ kind: "idle", text: "" });

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting.current) return;
    submitting.current = true;
    setStatus({ kind: "sending", text: "Sending your enquiry to the school..." });

    const form = new FormData(event.currentTarget);
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 25000);

    try {
      const response = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          studentName: form.get("studentName"),
          guardianName: form.get("guardianName"),
          guardianPhone: form.get("guardianPhone"),
          email: form.get("email"),
          applyingFor: form.get("applyingFor"),
          message: form.get("message"),
          website: form.get("website"),
          consent: form.has("consent"),
        }),
        signal: controller.signal,
      });

      if (response.status === 429) {
        setStatus({ kind: "error", text: "Too many enquiries. Please wait a minute or call the school office." });
        return;
      }
      if (!response.headers.get("content-type")?.includes("application/json")) {
        throw new Error("The online enquiry service is unavailable here. No delivery was confirmed. Please call the school office.");
      }

      const result = (await response.json()) as EnquiryResponse;
      if (result.success && response.ok) {
        setStatus({ kind: "success", text: result.message || "Notifications were accepted by the providers.", details: result });
      } else if (result.partial) {
        setStatus({ kind: "partial", text: result.message || "Some notifications could not be confirmed. Please call the school.", details: result });
      } else {
        setStatus({
          kind: "error",
          text: result.error || result.message || "The enquiry was not sent. Please call the school office.",
        });
      }
    } catch (error) {
      setStatus({
        kind: "error",
        text: error instanceof DOMException && error.name === "AbortError"
          ? "The request timed out. Delivery could not be confirmed; please call the school before trying again."
          : error instanceof Error
            ? error.message
            : "The online service could not be reached. No delivery was confirmed. Please call the school.",
      });
    } finally {
      window.clearTimeout(timeout);
      submitting.current = false;
    }
  };

  const input =
    "w-full rounded-xl border border-white/15 bg-white/8 px-4 py-3 text-sm font-semibold text-white placeholder:text-ink-100/35 outline-none transition-all duration-300 focus:border-saffron-400 focus:bg-white/12 focus:ring-2 focus:ring-saffron-400/25";
  const label = "mb-1.5 block text-[11px] font-extrabold uppercase tracking-[0.16em] text-ink-100/60";

  if (status.kind === "success" || status.kind === "partial") {
    const fullyAccepted = status.kind === "success";
    return (
      <div className="glass-dark flex h-full min-h-[420px] flex-col items-center justify-center rounded-3xl p-10 text-center">
        <span className={`flex h-20 w-20 items-center justify-center rounded-full ${fullyAccepted ? "bg-leaf-500/20 text-leaf-500" : "bg-saffron-500/20 text-saffron-400"}`}>
          <Icon name={fullyAccepted ? "check" : "bell"} className="h-10 w-10" />
        </span>
        <h3 className="mt-6 font-display text-3xl font-semibold text-white">
          {fullyAccepted ? "Enquiry submitted" : "Please confirm by phone"}
        </h3>
        <p role="status" className="mt-3 max-w-md text-sm leading-relaxed text-ink-100/80">
          {status.text}
        </p>
        {status.details?.reference && <p className="mt-3 text-xs font-semibold text-ink-100/55">Reference: {status.details.reference}</p>}
        {status.kind === "partial" && (
          <div className="mt-4 text-sm leading-relaxed text-ink-100/75">
            <p>Email accepted: {status.details?.emailAccepted ? "Yes" : "No"}</p>
            <p>SMS accepted: {status.details?.smsAccepted?.length ?? 0} of 3 numbers</p>
            <p className="mt-2 text-xs">Please do not resubmit the same enquiry automatically; it may create duplicates.</p>
          </div>
        )}
        <p className="mt-4 text-xs text-ink-100/55">Provider acceptance is not final email or SMS delivery confirmation.</p>
        <a href={`tel:${CONTACT_INFO.phones[0].replace(/\s/g, "")}`} className="mt-5 text-sm font-extrabold text-saffron-400 underline underline-offset-4">
          Call {CONTACT_INFO.phones[0]}
        </a>
        <button
          type="button"
          onClick={() => setStatus({ kind: "idle", text: "" })}
          className="mt-6 rounded-full border border-white/25 bg-white/8 px-6 py-2.5 text-sm font-extrabold uppercase tracking-wider text-white transition-colors hover:bg-white/15"
        >
          Start a New Enquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} aria-busy={status.kind === "sending"} className="glass-dark rounded-3xl p-7 md:p-8">
      <h3 className="font-display text-2xl font-semibold text-white">Send an Enquiry</h3>
      <p className="mt-1.5 text-sm leading-relaxed text-ink-100/70">
        Submit your details to the school office by email and SMS. Filling the form alone does not send anything.
      </p>
      <p className="mt-2 break-words text-xs leading-relaxed text-ink-100/55">
        Email: {CONTACT_INFO.email} | SMS alerts: {CONTACT_INFO.phones.join(", ")}, +91 8002162800
      </p>
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
        <label htmlFor="f-website">Leave this empty</label>
        <input id="f-website" name="website" tabIndex={-1} autoComplete="off" />
      </div>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div>
          <label className={label} htmlFor="f-name">Student Name</label>
          <input id="f-name" name="studentName" required maxLength={80} autoComplete="name" placeholder="e.g. Aarav Kumar" className={input} />
        </div>
        <div>
          <label className={label} htmlFor="f-guardian">Parent / Guardian Name</label>
          <input id="f-guardian" name="guardianName" required maxLength={80} autoComplete="off" placeholder="e.g. Priya Kumar" className={input} />
        </div>
        <div>
          <label className={label} htmlFor="f-phone">Parent / Guardian Phone</label>
          <input id="f-phone" name="guardianPhone" required type="tel" inputMode="tel" maxLength={24} autoComplete="tel" placeholder="+91 XXXXX XXXXX" className={input} />
        </div>
        <div>
          <label className={label} htmlFor="f-email">Email (optional)</label>
          <input id="f-email" name="email" type="email" maxLength={254} autoComplete="email" placeholder="parent@example.com" className={input} />
        </div>
        <div className="sm:col-span-2">
          <label className={label} htmlFor="f-class">Applying For</label>
          <select id="f-class" name="applyingFor" required defaultValue="" className={`${input} appearance-none`}>
            <option value="" disabled className="bg-ink-900">Select a class</option>
            {CLASSES.map((c) => (
              <option key={c} value={c} className="bg-ink-900">
                {c}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className={label} htmlFor="f-msg">Message (optional)</label>
          <textarea id="f-msg" name="message" rows={4} maxLength={600} placeholder="Ask us anything about admission, fees, timings..." className={`${input} resize-none`} />
        </div>
      </div>
      <label className="mt-5 flex cursor-pointer items-start gap-3 text-xs leading-relaxed text-ink-100/70">
        <input type="checkbox" name="consent" required className="mt-0.5 h-4 w-4 shrink-0 accent-saffron-500" />
        I agree to share these details with Shantiniketan Adarsh Vidyalaya by email and SMS so the school can contact me about my enquiry.
      </label>
      {status.kind === "error" && (
        <div role="alert" className="mt-5 rounded-xl border border-saffron-400/30 bg-saffron-500/10 p-4 text-sm leading-relaxed text-saffron-100">
          <p>{status.text}</p>
          <a href={`tel:${CONTACT_INFO.phones[0].replace(/\s/g, "")}`} className="mt-2 inline-block font-extrabold text-saffron-400 underline underline-offset-4">
            Call {CONTACT_INFO.phones[0]}
          </a>
        </div>
      )}
      <button
        type="submit"
        disabled={status.kind === "sending"}
        className="shine group mt-6 inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-saffron-500 px-7 py-4 text-sm font-extrabold uppercase tracking-wider text-ink-950 shadow-xl shadow-saffron-500/25 transition-all duration-300 hover:-translate-y-0.5 hover:bg-saffron-400 disabled:cursor-wait disabled:opacity-60 sm:w-auto"
      >
        <Icon name={status.kind === "sending" ? "clock" : "send"} className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-0.5" />
        {status.kind === "sending" ? "Sending..." : "Submit Enquiry"}
      </button>
      {status.kind === "sending" && <p role="status" className="mt-3 text-sm text-ink-100/70">{status.text}</p>}
    </form>
  );
}

export default function Contact() {
  return (
    <section id="contact" className="relative overflow-hidden bg-ink-950 pt-24 md:pt-28">
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(50% 40% at 15% 20%, rgba(47,114,219,0.22), transparent 60%), radial-gradient(45% 40% at 90% 60%, rgba(247,148,29,0.12), transparent 60%)",
        }}
        aria-hidden="true"
      />
      <IosBubbles count={3} />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-8 top-8 select-none font-display text-[15vw] font-black leading-none text-outline"
      >
        HELLO
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 md:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6 pb-12" data-reveal="fade">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.22em] text-saffron-400">
              <span className="font-display text-xs font-black tracking-normal text-gold-400">08</span>
              <Icon name="phone" className="h-3.5 w-3.5" />
              Contact Us
            </span>
            <h2 className="mt-5 font-display text-4xl font-semibold leading-tight text-white md:text-5xl">
              We'd Love to <span className="italic text-saffron-400">Hear From You</span>
            </h2>
          </div>
          <a
            href={`tel:${CONTACT_INFO.phones[0].replace(/\s/g, "")}`}
            className="group inline-flex items-center gap-3 rounded-2xl border border-white/15 bg-white/6 px-6 py-4 backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/12"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-saffron-500 text-ink-950 transition-transform duration-300 group-hover:scale-110">
              <Icon name="phone" className="h-5 w-5" />
            </span>
            <span>
              <span className="block text-[11px] font-extrabold uppercase tracking-wider text-ink-100/60">Call us now</span>
              <span className="block text-base font-extrabold text-white">{CONTACT_INFO.phones[0]}</span>
            </span>
          </a>
        </div>

        <div className="grid gap-8 lg:grid-cols-12">
          <div className="space-y-4 lg:col-span-5">
            {INFO.map((c, i) => (
              <div
                key={c.label}
                className="glass-dark group flex items-start gap-4 rounded-2xl p-5 transition-all duration-300 hover:-translate-y-0.5 hover:border-saffron-400/30"
                data-reveal="left"
                style={{ "--rd": `${i * 0.08}s` } as CSSProperties}
              >
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-saffron-500/15 text-saffron-400 transition-transform duration-300 group-hover:scale-110">
                  <Icon name={c.icon} className="h-5.5 w-5.5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-ink-100/55">{c.label}</p>
                  <p className="mt-1 break-words text-[15px] font-bold leading-relaxed text-white">{c.value}</p>
                </div>
              </div>
            ))}
            <div className="flex items-center gap-3 pt-2" data-reveal="left" style={{ "--rd": "0.35s" } as CSSProperties}>
              {["facebook", "instagram", "youtube"].map((s) => (
                <a
                  key={s}
                  href="#contact"
                  aria-label={s}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-white/15 bg-white/6 text-cream-100/80 transition-all duration-300 hover:-translate-y-1 hover:border-saffron-400/50 hover:text-saffron-400"
                >
                  <Icon name={s} className="h-5 w-5" />
                </a>
              ))}
              <span className="ml-1 text-xs font-bold uppercase tracking-wider text-ink-100/45">Follow S.A.V. Raxaul</span>
            </div>
          </div>

          <div className="lg:col-span-7" data-reveal="right">
            <EnquiryForm />
          </div>
        </div>

        <MapCard />
      </div>

      {/* footer */}
      <footer className="relative z-10 mt-24 border-t border-white/10">
        <div className="mx-auto max-w-7xl px-4 py-14 md:px-6">
          <div className="grid gap-10 md:grid-cols-12">
            <div className="md:col-span-5">
              <div className="flex items-center gap-3">
                <Crest className="h-14 w-14" />
                <div>
                  <p className="font-display text-xl font-semibold text-white">Shantiniketan Adarsh Vidyalaya</p>
                  <p className="text-[10px] font-extrabold uppercase tracking-[0.3em] text-saffron-400">S.A.V. · Raxaul</p>
                </div>
              </div>
              <p className="mt-5 max-w-md text-sm leading-relaxed text-ink-100/65">
                Shantiniketan Adarsh Vidyalaya is dedicated to providing quality education with discipline, values, and
                holistic development — from Nursery to Class X.
              </p>
              <div className="mt-5 flex items-center gap-2.5 overflow-hidden rounded-xl border border-white/10 bg-white/5">
                <div className="h-10 w-10 shrink-0">
                  <FadeImg src={IMG.campus} alt="" className="h-full w-full object-cover" />
                </div>
                <p className="text-xs font-bold text-ink-100/60">
                  Best School Award 2025-2026
                  <span className="block text-[10px] font-semibold text-ink-100/40">East Champaran District · Bihar</span>
                </p>
              </div>
            </div>

            <div className="md:col-span-2">
              <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-saffron-400">Quick Links</p>
              <ul className="mt-4 space-y-2.5">
                {NAV_LINKS.map((l) => (
                  <li key={l.href}>
                    <a href={l.href} className="group inline-flex items-center gap-2 text-sm font-bold text-ink-100/70 transition-colors hover:text-saffron-400">
                      <span className="h-1 w-1 rounded-full bg-saffron-400/60 transition-transform duration-300 group-hover:scale-150" />
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div className="md:col-span-2">
              <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-saffron-400">Classes</p>
              <ul className="mt-4 space-y-2.5">
                {["Nursery", "LKG", "UKG", "Class I – V", "Class VI – X"].map((c) => (
                  <li key={c}>
                    <a href="#academics" className="group inline-flex items-center gap-2 text-sm font-bold text-ink-100/70 transition-colors hover:text-saffron-400">
                      <span className="h-1 w-1 rounded-full bg-saffron-400/60 transition-transform duration-300 group-hover:scale-150" />
                      {c}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div className="md:col-span-3">
              <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-saffron-400">Reach Us</p>
              <ul className="mt-4 space-y-3 text-sm font-semibold text-ink-100/70">
                <li className="flex items-start gap-2.5">
                  <Icon name="pin" className="mt-0.5 h-4 w-4 shrink-0 text-saffron-400" />
                  {CONTACT_INFO.address}
                </li>
                <li className="flex items-center gap-2.5">
                  <Icon name="phone" className="h-4 w-4 shrink-0 text-saffron-400" />
                  {CONTACT_INFO.phones.join(", ")}
                </li>
                <li className="flex items-center gap-2.5 break-all">
                  <Icon name="mail" className="h-4 w-4 shrink-0 text-saffron-400" />
                  {CONTACT_INFO.email}
                </li>
                <li className="flex items-center gap-2.5">
                  <Icon name="clock" className="h-4 w-4 shrink-0 text-saffron-400" />
                  {CONTACT_INFO.hours}
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-6 gap-y-3 px-4 py-5 text-center text-xs font-semibold text-ink-100/50 md:justify-between md:px-6">
            <p>© 2026 Shantiniketan Adarsh Vidyalaya (S.A.V.). All Rights Reserved.</p>
            <p className="flex items-center gap-1.5">
              Made with <Icon name="heart" className="h-3.5 w-3.5 text-saffron-400" /> in Raxaul · East Champaran · Bihar
            </p>
          </div>
        </div>
      </footer>
    </section>
  );
}
