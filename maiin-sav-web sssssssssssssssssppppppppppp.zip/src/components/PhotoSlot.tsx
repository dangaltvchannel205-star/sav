import { useEffect, useState } from "react";

const photoKey = (id: string) => `sav-photo-${id}`;

/** Local gallery previews stay in the visitor's browser; they are never published. */
export function fileToDataURL(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) return Promise.reject(new Error("Choose an image file."));
  if (file.size <= 800_000) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error("Could not read the photo."));
      reader.readAsDataURL(file);
    });
  }

  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    image.onload = () => {
      const max = 900;
      const scale = Math.min(1, max / image.width, max / image.height);
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(image.width * scale);
      canvas.height = Math.round(image.height * scale);
      const context = canvas.getContext("2d");
      if (!context) {
        URL.revokeObjectURL(url);
        reject(new Error("Canvas is not supported."));
        return;
      }
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.82));
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read the photo."));
    };
    image.src = url;
  });
}

export function PhotoSlot({
  id,
  name,
  initials,
  defaultSrc,
  className = "",
}: {
  id: string;
  name: string;
  initials: string;
  defaultSrc?: string;
  className?: string;
}) {
  const [publishedUnavailable, setPublishedUnavailable] = useState(false);
  const [previousLocalPhoto, setPreviousLocalPhoto] = useState<string | null>(null);

  useEffect(() => {
    // Existing browser-only uploads remain visible if the public image is unavailable.
    try {
      setPreviousLocalPhoto(localStorage.getItem(photoKey(id)));
    } catch {
      setPreviousLocalPhoto(null);
    }
  }, [id]);

  // Published images always take priority: everyone sees the same portrait once it exists.
  const source = !publishedUnavailable && defaultSrc ? defaultSrc : previousLocalPhoto;

  return (
    <div className={`relative h-full w-full overflow-hidden ${className}`}>
      {source ? (
        <img
          src={source}
          alt={name}
          loading="lazy"
          decoding="async"
          onError={() => {
            if (source === defaultSrc) setPublishedUnavailable(true);
            else setPreviousLocalPhoto(null);
          }}
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="pattern-dots-dark flex h-full w-full flex-col items-center justify-center gap-3 bg-[linear-gradient(140deg,#e1edff_0%,#fbf7ef_55%,#ffe9cb_100%)]">
          <span className="flex h-20 w-20 items-center justify-center rounded-full border border-royal-100 bg-white/85 font-display text-3xl font-bold text-royal-700 shadow-lg">
            {initials}
          </span>
          <span className="px-6 text-center text-[11px] font-extrabold uppercase tracking-[0.22em] text-royal-700/70">
            {name}
          </span>
        </div>
      )}
    </div>
  );
}