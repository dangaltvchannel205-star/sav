import type { CSSProperties } from "react";
import { FadeImg, Icon, SectionHead } from "./Shared";
import { CONTACT_INFO, IMG, NOTICES } from "../data";

const TAG_TONE: Record<string, string> = {
  Admissions: "bg-saffron-100 text-saffron-600",
  Award: "bg-gold-300/30 text-ink-800",
  Holiday: "bg-leaf-100 text-leaf-600",
  Event: "bg-royal-100 text-royal-700",
  Academics: "bg-ink-900/8 text-ink-800",
};

export default function Notices() {
  return (
    <section id="notices" className="relative overflow-hidden bg-royal-100/45 py-24 md:py-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-8 top-6 select-none font-display text-[15vw] font-black leading-none text-outline-dark"
      >
        NOTICE
      </div>

      <div className="relative mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead
          overline="Notice Board"
          icon="bell"
          num="06"
          title={
            <>
              Latest <span className="italic text-royal-600">Notices</span> &amp; Updates
            </>
          }
          sub="Stay informed — announcements, holidays, events and academic updates, updated regularly by the school office."
        />

        <div className="grid gap-8 lg:grid-cols-3">
          {/* notice list */}
          <div className="space-y-4 lg:col-span-2">
            {NOTICES.map((n, i) => (
              <article
                key={n.title}
                className={`glass group relative flex gap-4 rounded-2xl p-4 transition-all duration-300 hover:-translate-x-0 md:hover:translate-x-1 md:p-5 ${
                  n.pinned ? "border-2 border-saffron-400/60 shadow-lg shadow-saffron-500/10" : ""
                }`}
                data-reveal
                style={{ "--rd": `${i * 0.08}s` } as CSSProperties}
              >
                <div className="flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-xl bg-ink-900 text-white">
                  <span className="text-base font-extrabold leading-none">{n.date.split(" ")[0]}</span>
                  <span className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-saffron-400">
                    {n.date.split(" ").slice(1).join(" ")}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-lg font-semibold leading-snug text-ink-900">{n.title}</h3>
                    {n.pinned && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-saffron-500 px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-ink-950">
                        <Icon name="pin" className="h-3 w-3" />
                        Pinned
                      </span>
                    )}
                    <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider ${TAG_TONE[n.tag] ?? TAG_TONE.Academics}`}>
                      {n.tag}
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-900/65">{n.text}</p>
                </div>
                <Icon name="arrow" className="mt-1 hidden h-5 w-5 shrink-0 text-royal-600 opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100 sm:block" />
              </article>
            ))}
          </div>

          {/* side: calendar + helpline */}
          <div className="space-y-6">
            <div className="glass overflow-hidden rounded-3xl" data-reveal="right">
              <div className="kb-hover relative overflow-hidden">
                <FadeImg src={IMG.calendar} alt="School academic calendar 2026-27" className="aspect-[16/10] w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent" aria-hidden="true" />
                <p className="absolute bottom-3 left-4 font-display text-lg font-bold text-white">School Calendar 2026-27</p>
              </div>
              <div className="p-5">
                <p className="text-sm leading-relaxed text-ink-900/65">
                  Academic calendar with exam dates, holiday list and term schedule for the 2026-27 session.
                </p>
                <a
                  href="#contact"
                  className="mt-4 inline-flex items-center gap-2 text-sm font-extrabold text-royal-700 transition-colors hover:text-royal-600"
                >
                  Get the full calendar
                  <Icon name="arrow" className="h-4 w-4" />
                </a>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-ink-900 p-6 text-white shadow-lg shadow-ink-950/20" data-reveal="right" style={{ "--rd": "0.12s" } as CSSProperties}>
              <div className="pattern-dots absolute inset-0 opacity-30" aria-hidden="true" />
              <div className="relative">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-saffron-500/20 text-saffron-400">
                  <Icon name="phone" className="h-5.5 w-5.5" />
                </span>
                <h3 className="mt-4 font-display text-xl font-semibold text-white">Need a quick answer?</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-100">
                  Call our office on <span className="font-bold text-white">Mon – Sat, 8:00 AM – 2:00 PM</span>.
                </p>
                <a
                  href={`tel:${CONTACT_INFO.phones[0].replace(/\s/g, "")}`}
                  className="shine mt-4 inline-flex items-center gap-2 rounded-full bg-saffron-500 px-5 py-2.5 text-sm font-extrabold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-saffron-400"
                >
                  <Icon name="phone" className="h-4 w-4" />
                  {CONTACT_INFO.phones[0]}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
