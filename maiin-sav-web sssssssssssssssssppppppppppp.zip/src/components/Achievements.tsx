import type { CSSProperties } from "react";
import { FadeImg, Icon, IosBubbles, RotBadge, SectionHead } from "./Shared";
import { ACHIEVEMENT_CARDS, IMG, MOMENTS } from "../data";

export default function Achievements() {
  return (
    <section id="achievements" className="relative overflow-hidden bg-ink-950 py-24 md:py-28">
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(55% 45% at 22% 30%, rgba(247,148,29,0.16), transparent 60%), radial-gradient(55% 50% at 85% 75%, rgba(47,114,219,0.22), transparent 60%)",
        }}
        aria-hidden="true"
      />
      <div className="pattern-dots absolute inset-0 opacity-40" aria-hidden="true" />
      <IosBubbles count={3} />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-8 top-8 select-none font-display text-[15vw] font-black leading-none text-outline"
      >
        AWARD
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 md:px-6">
        <SectionHead
          overline="Our Achievement"
          icon="trophy"
          num="04"
          light
          title={
            <>
              A Milestone of <span className="italic text-gold-400">Excellence</span>
            </>
          }
        />

        {/* featured award */}
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="relative mx-auto w-full max-w-[520px]" data-reveal="left">
            <div className="absolute -inset-10 hidden rounded-full bg-gold-400/15 blur-3xl md:block" aria-hidden="true" />
            <div className="relative -rotate-[1.6deg] overflow-hidden rounded-[26px] border-4 border-gold-400/50 shadow-2xl shadow-ink-950/80">
              <FadeImg src={IMG.award} alt="Best School Award 2025-2026 certificate" className="w-full object-cover" />
              <div className="shine absolute inset-0" aria-hidden="true" />
            </div>
            <div className="absolute -bottom-10 -right-4 text-gold-400 drop-shadow-xl sm:-right-8">
              <RotBadge text="EXCELLENCE IN EDUCATION · EAST CHAMPARAN · BIHAR · " className="h-27 w-27" icon="star" />
            </div>
          </div>

          <div data-reveal="right">
            <p className="inline-flex items-center gap-2 rounded-full border border-gold-400/40 bg-gold-400/10 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.2em] text-gold-400">
              <Icon name="medal" className="h-3.5 w-3.5" />
              Award · 2025-2026
            </p>
            <h3 className="mt-5 font-display text-4xl font-semibold leading-tight text-white md:text-5xl">
              Best School Award
              <span className="mt-1 block italic text-gold-400">2025 – 2026</span>
            </h3>
            <p className="mt-6 text-base leading-relaxed text-ink-100/85 md:text-lg">
              <strong className="font-bold text-white">Shantiniketan Adarsh Vidyalaya, Raxaul</strong> has been awarded the{" "}
              <strong className="font-extrabold text-gold-400">Best School Award 2025-2026</strong> for excellence in education in
              <strong className="font-bold text-white"> East Champaran District (Bihar)</strong>.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              {["Excellence in Education", "East Champaran District", "Bihar, India"].map((c) => (
                <span key={c} className="glass-dark rounded-full px-4 py-2 text-xs font-extrabold uppercase tracking-wider text-cream-100/90">
                  {c}
                </span>
              ))}
            </div>
            <div className="mt-9 flex flex-wrap gap-4">
              <a
                href="#facilities"
                className="shine group inline-flex items-center gap-2.5 rounded-full bg-gold-400 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-ink-950 shadow-xl shadow-gold-400/25 transition-all duration-300 hover:-translate-y-1 hover:bg-gold-300"
              >
                Explore Our Campus
                <Icon name="arrow" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
              <a
                href="#gallery"
                className="inline-flex items-center gap-2.5 rounded-full border border-white/25 bg-white/5 px-7 py-3.5 text-sm font-extrabold uppercase tracking-wider text-white backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:bg-white/15"
              >
                View Gallery
              </a>
            </div>
          </div>
        </div>

        {/* achievement cards */}
        <div className="mt-28 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {ACHIEVEMENT_CARDS.map((a, i) => (
            <article
              key={a.title}
              className="glass-dark card-lift group rounded-3xl p-6"
              data-reveal
              style={{ "--rd": `${i * 0.1}s` } as CSSProperties}
            >
              <span className="inline-flex h-13 w-13 items-center justify-center rounded-2xl bg-gold-400/15 p-3 text-gold-400 transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110">
                <Icon name={a.icon} className="h-6.5 w-6.5" />
              </span>
              <h4 className="mt-4 font-display text-xl font-semibold text-white">{a.title}</h4>
              <p className="mt-2 text-sm leading-relaxed text-ink-100/70">{a.text}</p>
            </article>
          ))}
        </div>

        {/* moments */}
        <div className="mt-16">
          <p className="mb-6 text-center font-display text-2xl font-semibold text-white" data-reveal="fade">
            Moments of <span className="italic text-gold-400">Pride</span>
          </p>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {MOMENTS.map((m, i) => (
              <a
                key={m.caption}
                href="#gallery"
                className="kb-hover group relative block overflow-hidden rounded-2xl"
                data-reveal
                style={{ "--rd": `${i * 0.08}s` } as CSSProperties}
              >
                <FadeImg src={m.img} alt={m.caption} className="aspect-[4/3] w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/85 via-transparent to-transparent" aria-hidden="true" />
                <p className="absolute bottom-3 left-3 flex items-center gap-2 text-sm font-extrabold text-white">
                  <span className="h-1.5 w-1.5 rounded-full bg-gold-400" />
                  {m.caption}
                </p>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
