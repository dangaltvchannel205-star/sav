import { useState, type CSSProperties, type ReactNode } from "react";

/* ================= icons (custom inline SVG set) ================= */

const ICON_PATHS: Record<string, ReactNode> = {
  spark: <path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.4L12 3z" />,
  arrow: (<><path d="M4.5 12h15" /><path d="M13.5 6l6 6-6 6" /></>),
  check: <path d="M4.5 12.5l5 5L20 6.5" />,
  phone: (
    <path d="M6.8 10.6a14.5 14.5 0 0 0 6.6 6.6l2.1-2.1a1.6 1.6 0 0 1 1.7-.4c1 .3 2.2.5 3.3.5.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.9 21 3 13.1 3 4c0-.6.4-1 1-1h3.8c.6 0 1 .4 1 1 0 1.1.2 2.3.5 3.3.1.6 0 1.2-.4 1.7L6.8 10.6z" />
  ),
  mail: (<><rect x="3.5" y="5.5" width="17" height="13" rx="2" /><path d="M4 7l8 6 8-6" /></>),
  pin: (<><path d="M12 21s-7-5.6-7-11a7 7 0 1 1 14 0c0 5.4-7 11-7 11z" /><circle cx="12" cy="10" r="2.6" /></>),
  clock: (<><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3.2 2" /></>),
  book: (<><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v14.5H6.5A2.5 2.5 0 0 0 4 20z" /><path d="M4 20a2.5 2.5 0 0 1 2.5-2.5H20V20H6.5" /></>),
  flask: (<><path d="M9.5 3h5" /><path d="M10.5 3v5.2L4.8 17.4A2 2 0 0 0 6.5 20h11a2 2 0 0 0 1.7-2.6L13.5 8.2V3" /><path d="M7.5 14.5h9" /></>),
  monitor: (<><rect x="3" y="4" width="18" height="12.5" rx="1.6" /><path d="M9 20.5h6M12 16.5v4" /></>),
  leaf: (<><path d="M5.5 18.5C5.5 9.5 13 4.5 20 4.5c0 7.5-4 14-12 14" /><path d="M5.5 18.5c2-5 5.5-8.5 10.5-10.5" /></>),
  ball: (<><circle cx="12" cy="12" r="8.6" /><path d="M12 8l3.8 2.8-1.4 4.4H9.6L8.2 10.8 12 8z" /></>),
  bus: (<><path d="M4.5 16.5V6a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v10.5" /><path d="M4.5 12h15" /><path d="M4.5 16.5h1.5M18 16.5h1.5" /><circle cx="8" cy="18.5" r="1.6" /><circle cx="16" cy="18.5" r="1.6" /></>),
  bell: (<><path d="M6.3 9.5a5.7 5.7 0 0 1 11.4 0c0 4.7 1.8 5.7 1.8 5.7H4.5s1.8-1 1.8-5.7z" /><path d="M10 18.8a2 2 0 0 0 4 0" /></>),
  shield: (<><path d="M12 3l7.5 2.8V12c0 4.8-3.2 7.8-7.5 9-4.3-1.2-7.5-4.2-7.5-9V5.8L12 3z" /><path d="M8.8 12l2.3 2.3 4.2-4.2" /></>),
  star: <path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.9L12 17l-5.2 2.7 1-5.9L3.5 9.7l5.9-.9L12 3.5z" />,
  trophy: (<><path d="M8 4h8v3.5a4 4 0 0 1-8 0V4z" /><path d="M8 5H4.5c0 3.8 1.5 5.8 3.6 6M16 5h3.5c0 3.8-1.5 5.8-3.6 6" /><path d="M12 11.5V15M8.5 19.5h7M10 19.5l.6-4.5h2.8l.6 4.5" /></>),
  target: (<><circle cx="12" cy="12" r="8.4" /><circle cx="12" cy="12" r="4.6" /><circle cx="12" cy="12" r="1.1" /></>),
  heart: <path d="M12 20s-7.4-4.7-9.2-9.1A5.1 5.1 0 0 1 12 6.7a5.1 5.1 0 0 1 9.2 4.2C19.4 15.3 12 20 12 20z" />,
  users: (<><circle cx="9" cy="8" r="3.4" /><path d="M3.5 20c.5-3.9 2.6-5.9 5.5-5.9s5 2 5.5 5.9" /><path d="M15.5 5a3.4 3.4 0 0 1 0 6.2M17 14.4c2.2.6 3.3 2.3 3.5 5.6" /></>),
  compass: (<><circle cx="12" cy="12" r="8.5" /><path d="M15.6 8.4l-2 5.2-5.2 2 2-5.2 5.2-2z" /></>),
  close: (<><path d="M6 6l12 12M18 6L6 18" /></>),
  chevron: <path d="M6 9.5l6 6 6-6" />,
  calendar: (<><rect x="4" y="5.5" width="16" height="15" rx="2" /><path d="M4 10h16M8.5 3v4.5M15.5 3v4.5" /></>),
  doc: (<><path d="M7 3h7.5L18 6.5V21H7z" /><path d="M14 3v4h4M10 12.5h5M10 16.5h5" /></>),
  music: (<><path d="M9.5 18.2V5.5l10-2.2v12.4" /><circle cx="7" cy="18.4" r="2.5" /><circle cx="17" cy="15.8" r="2.5" /></>),
  drop: <path d="M12 3.2s6 6.6 6 10.8a6 6 0 0 1-12 0C6 9.8 12 3.2 12 3.2z" />,
  eye: (<><path d="M2.8 12S6.2 5.8 12 5.8 21.2 12 21.2 12 17.8 18.2 12 18.2 2.8 12 2.8 12z" /><circle cx="12" cy="12" r="2.8" /></>),
  grad: (<><path d="M12 4.5L2 9.3l10 4.8 10-4.8-10-4.8z" /><path d="M6.5 11.8v4.4c0 1.5 2.5 3 5.5 3s5.5-1.5 5.5-3v-4.4M22 9.5v5" /></>),
  pen: (<><path d="M14.5 4l5.5 5.5-9.5 9.5L4 21l2-6.5L15.5 5z" /><path d="M12.5 6.5L18 12" /></>),
  sun: (<><circle cx="12" cy="12" r="4" /><path d="M12 3v2.2M12 18.8V21M3 12h2.2M18.8 12H21M5.6 5.6l1.6 1.6M16.8 16.8l1.6 1.6M18.4 5.6l-1.6 1.6M7.2 16.8l-1.6 1.6" /></>),
  building: (<><path d="M4 21h16M6.5 21V5.5L12 3.5l5.5 2V21" /><path d="M9.5 8.5h1.4M13.1 8.5h1.4M9.5 12h1.4M13.1 12h1.4M9.5 15.5h1.4M13.1 15.5h1.4" /></>),
  medal: (<><circle cx="12" cy="9" r="5.2" /><path d="M9.2 13.4L7.5 21l4.5-2.3L16.5 21l-1.7-7.6" /><path d="M12 6.8l.9 1.8 2 .3-1.4 1.4.3 2-1.8-1-1.8 1 .3-2-1.4-1.4 2-.3.9-1.8z" /></>),
  palette: (<><path d="M12 20.5a8.5 8.5 0 1 1 8.5-8.5c0 2.3-1.4 3.7-3.3 3.7H15a1.9 1.9 0 0 0-1.4 3.2c.8.8.2 1.6-1.6 1.6z" /><circle cx="8" cy="10" r="1.1" /><circle cx="12" cy="7.5" r="1.1" /><circle cx="16" cy="10" r="1.1" /></>),
  grid: (<><rect x="4" y="4" width="6.8" height="6.8" rx="1" /><rect x="13.2" y="4" width="6.8" height="6.8" rx="1" /><rect x="4" y="13.2" width="6.8" height="6.8" rx="1" /><rect x="13.2" y="13.2" width="6.8" height="6.8" rx="1" /></>),
  plus: (<><path d="M12 5v14" /><path d="M5 12h14" /></>),
  send: (<><path d="M21 3.5L10.5 14M21 3.5l-6.8 17-3.7-7.2L3.5 9.6 21 3.5z" /></>),
  facebook: <path d="M14 8.5h2.5V5.5H14a4 4 0 0 0-4 4v2H8v3h2v6h3v-6h2.2l.8-3H13v-2a.9.9 0 0 1 1-.9z" />,
  instagram: (<><rect x="4" y="4" width="16" height="16" rx="4.5" /><circle cx="12" cy="12" r="3.6" /><circle cx="16.9" cy="7.1" r="0.9" /></>),
  youtube: (<><rect x="3" y="6" width="18" height="12.5" rx="3.5" /><path d="M10.5 9.7l4.6 2.55-4.6 2.55V9.7z" /></>),
};

export function Icon({ name, className = "h-5 w-5" }: { name: string; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {ICON_PATHS[name] ?? ICON_PATHS.star}
    </svg>
  );
}

/* ================= school crest (real logo) ================= */

export const SCHOOL_LOGO = "https://www.savraxaul.in/images/reallogo.png";

export function Crest({ className = "h-12 w-12" }: { className?: string }) {
  const [broken, setBroken] = useState(false);

  if (!broken) {
    return (
      <span className={`block shrink-0 overflow-hidden rounded-full shadow-lg ring-2 ring-white/25 ${className}`}>
        <img
          src={SCHOOL_LOGO}
          alt="Shantiniketan Adarsh Vidyalaya logo"
          className="h-full w-full object-cover"
          loading="eager"
          decoding="async"
          onError={() => setBroken(true)}
        />
      </span>
    );
  }

  /* fallback if the remote logo can't load */
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden="true">
      <circle cx="60" cy="60" r="58" fill="#0A1B33" />
      <circle cx="60" cy="60" r="58" fill="none" stroke="#F7941D" strokeWidth="3" />
      <circle cx="60" cy="60" r="46.5" fill="#FBF7EF" />
      <defs>
        <path id="crest-arc-top" d="M60 60 m-40 0 a40 40 0 1 1 80 0" />
        <path id="crest-arc-bottom" d="M60 60 m40 0 a40 40 0 1 1 -80 0" />
      </defs>
      <text fill="#16345C" fontSize="7.4" fontWeight="800" letterSpacing="0.9" fontFamily="Manrope, sans-serif">
        <textPath href="#crest-arc-top" startOffset="50%" textAnchor="middle">
          SHANTINIKETAN ADARSH VIDYALAYA
        </textPath>
      </text>
      <text fill="#F7941D" fontSize="7.6" fontWeight="800" letterSpacing="3" fontFamily="Manrope, sans-serif">
        <textPath href="#crest-arc-bottom" startOffset="50%" textAnchor="middle">
          • RAXAUL •
        </textPath>
      </text>
      <path d="M60 26l21 7v18.5c0 13.5-8.8 22.6-21 27.3-12.2-4.7-21-13.8-21-27.3V33l21-7z" fill="#16345C" />
      <path d="M60 26l21 7v18.5c0 13.5-8.8 22.6-21 27.3V26z" fill="#0F2848" />
      <path d="M60 29.5l18 6v16.6c0 11.8-7.5 19.9-18 24.3V29.5z" fill="none" stroke="#F6C96B" strokeWidth="1.2" opacity="0.55" />
      {/* trophy */}
      <path d="M52.5 38h15v4.6a7.5 7.5 0 0 1-15 0V38z" fill="#F7941D" />
      <path d="M52.5 39h-4.2c0 3.6 1.4 5.5 3.4 6M67.5 39h4.2c0 3.6-1.4 5.5-3.4 6" fill="none" stroke="#F7941D" strokeWidth="1.6" />
      <path d="M60 48.5v3M56.5 53.5h7" stroke="#F7941D" strokeWidth="1.8" strokeLinecap="round" />
      {/* open book */}
      <path d="M44 59c5.4 2.2 10.4 2.2 16 0v11c-5.6 2.2-10.6 2.2-16 0V59z" fill="#FFFFFF" />
      <path d="M60 59c5.6 2.2 10.6 2.2 16 0v11c-5.4 2.2-10.4 2.2-16 0V59z" fill="#F6C96B" />
      <path d="M47 62c3 1 6 1 9.5 0M47 65.5c3 1 6 1 9.5 0M63.5 62c3.5 1 6.5 1 9.5 0M63.5 65.5c3.5 1 6.5 1 9.5 0" stroke="#16345C" strokeWidth="1" opacity="0.5" />
    </svg>
  );
}

/* ================= section heading ================= */

export function SectionHead({
  overline,
  icon = "spark",
  title,
  sub,
  light = false,
  center = false,
  num,
}: {
  overline: string;
  icon?: string;
  title: ReactNode;
  sub?: string;
  light?: boolean;
  center?: boolean;
  num?: string;
}) {
  return (
    <div className={`mb-12 max-w-3xl md:mb-16 ${center ? "mx-auto text-center" : ""}`} data-reveal="fade">
      <span
        className={`inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.22em] ${
          light
            ? "border border-white/20 bg-white/10 text-saffron-400"
            : "border border-ink-900/10 bg-white/70 text-royal-700 shadow-sm"
        }`}
      >
        {num && <span className={`font-display text-xs font-black tracking-normal ${light ? "text-gold-400" : "text-saffron-600"}`}>{num}</span>}
        <Icon name={icon} className="h-3.5 w-3.5" />
        {overline}
      </span>
      <h2
        className={`mt-5 font-display text-4xl font-semibold leading-[1.08] tracking-tight md:text-5xl ${
          light ? "text-white" : "text-ink-900"
        }`}
      >
        {title}
      </h2>
      {sub && (
        <p className={`mt-4 text-base leading-relaxed md:text-lg ${light ? "text-ink-100/85" : "text-ink-900/65"}`}>{sub}</p>
      )}
    </div>
  );
}

/* ================= iOS-style frosted bubbles (transform-only) ================= */

const IOS_BUBBLES = [
  { s: 190, l: 3, t: 10, o: 0.5 },
  { s: 110, l: 76, t: 6, o: 0.42 },
  { s: 74, l: 60, t: 64, o: 0.5 },
];

export function IosBubbles({ count = 3 }: { count?: number }) {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      {IOS_BUBBLES.slice(0, count).map((b, i) => (
        <span
          key={i}
          className="ios-bubble"
          style={
            {
              left: `${b.l}%`,
              top: `${b.t}%`,
              width: b.s,
              height: b.s,
              opacity: b.o,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}

/* ================= stats ================= */

export function Count({ to, suffix = "" }: { to: number; suffix?: string }) {
  return (
    <span>
      {to.toLocaleString("en-IN")}
      {suffix}
    </span>
  );
}

/* ================= rotating circular badge ================= */

export function RotBadge({ text, className = "h-28 w-28", icon = "trophy" }: { text: string; className?: string; icon?: string }) {
  return (
    <div className={`relative ${className}`}>
      <svg viewBox="0 0 100 100" className="spin-slow absolute inset-0 h-full w-full">
        <defs>
          <path id="rot-arc" d="M50 50 m-38 0 a38 38 0 1 1 76 0 a38 38 0 1 1 -76 0" />
        </defs>
        <text fill="currentColor" fontSize="10.2" fontWeight="800" letterSpacing="2.6" fontFamily="Manrope, sans-serif">
          <textPath href="#rot-arc">{text}</textPath>
        </text>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <Icon name={icon} className="h-7 w-7" />
      </div>
    </div>
  );
}

/* ================= image with fade-in ================= */

export function FadeImg({
  src,
  alt,
  className = "",
  eager = false,
}: {
  src: string;
  alt: string;
  className?: string;
  eager?: boolean;
}) {
  return (
    <img
      src={src}
      alt={alt}
      loading={eager ? "eager" : "lazy"}
      decoding="async"
      fetchPriority={eager ? "high" : "low"}
      className={className}
    />
  );
}
