import { useEffect, useLayoutEffect } from "react";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Categories from "./components/Categories";
import About from "./components/About";
import Academics from "./components/Academics";
import Campus from "./components/Campus";
import Achievements from "./components/Achievements";
import Gallery from "./components/Gallery";
import Notices from "./components/Notices";
import Admissions from "./components/Admissions";
import Contact from "./components/Contact";

export default function App() {
  useLayoutEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) return;

    const revealElements = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    const revealLine = window.innerHeight - 40;
    // Read positions before writing classes to avoid forcing repeated layout on load.
    const pending = revealElements.filter((element) => element.getBoundingClientRect().top >= revealLine);

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          entry.target.classList.add("is-in");
          observer.unobserve(entry.target);
        }
      },
      { rootMargin: "0px 0px -40px 0px", threshold: 0 }
    );

    for (const element of pending) {
      element.classList.add("scroll-reveal");
      observer.observe(element);
    }

    return () => {
      observer.disconnect();
      for (const element of pending) element.classList.remove("scroll-reveal");
    };
  }, []);

  useEffect(() => {
    let arrivalObserver: IntersectionObserver | null = null;
    let arrivalAnimation: Animation | null = null;
    let fallbackTimer: number | undefined;

    const navigate = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const clicked = event.target;
      if (!(clicked instanceof Element)) return;
      const link = clicked.closest<HTMLAnchorElement>('a[href^="#"]');
      const hash = link?.getAttribute("href");
      if (!hash || hash.length <= 1 || link?.hasAttribute("download")) return;

      const destination = document.getElementById(hash.slice(1));
      if (!destination) return;
      event.preventDefault();

      arrivalObserver?.disconnect();
      arrivalAnimation?.cancel();
      window.clearTimeout(fallbackTimer);

      if (window.location.hash !== hash) window.history.pushState(null, "", hash);
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const title = destination.querySelector<HTMLElement>("h1, h2, h3") ?? destination;
      const heading = title.closest<HTMLElement>("[data-reveal]") ?? title;

      // Replay just the destination, including on repeat visits to the same section.
      let played = false;
      const playArrival = () => {
        if (played) return;
        played = true;
        arrivalObserver?.disconnect();
        window.clearTimeout(fallbackTimer);
        heading.classList.add("is-in");
        if (reducedMotion) return;
        arrivalAnimation = heading.animate(
          [
            { opacity: 0.25, transform: "translate3d(0, 22px, 0)" },
            { opacity: 1, transform: "translate3d(0, 0, 0)" },
          ],
          { duration: 540, easing: "cubic-bezier(0.22, 1, 0.36, 1)" }
        );
      };

      if (!reducedMotion && "IntersectionObserver" in window) {
        arrivalObserver = new IntersectionObserver(
          (entries) => {
            if (entries[0]?.isIntersecting) playArrival();
          },
          { rootMargin: "-64px 0px -45% 0px" }
        );
        arrivalObserver.observe(heading);
        fallbackTimer = window.setTimeout(playArrival, 1700);
      }

      destination.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "start" });
      if (reducedMotion) playArrival();
    };

    document.addEventListener("click", navigate);
    return () => {
      document.removeEventListener("click", navigate);
      arrivalObserver?.disconnect();
      arrivalAnimation?.cancel();
      window.clearTimeout(fallbackTimer);
    };
  }, []);

  return (
    <div className="relative">
      <Nav />
      <main>
        <Hero />
        <Categories />
        <About />
        <Academics />
        <Campus />
        <Achievements />
        <Gallery />
        <Notices />
        <Admissions />
        <Contact />
      </main>
    </div>
  );
}
