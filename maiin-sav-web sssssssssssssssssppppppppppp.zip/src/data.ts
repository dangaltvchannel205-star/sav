export const IMG = {
  campus: "https://www.savraxaul.in/images/school5.jpeg",
  building: "https://www.savraxaul.in/images/school4.jpeg",
  sports: "https://www.savraxaul.in/images/activity.jpeg",
  lab: "https://www.savraxaul.in/images/lab1.jpeg",
  green: "https://www.savraxaul.in/images/green.jpeg",
  classroom: "https://www.savraxaul.in/images/classroom1.jpeg",
  award: "https://www.savraxaul.in/images/best-school-award.jpeg",
  reading: "https://www.savraxaul.in/images/reading.jpeg",
  science: "https://www.savraxaul.in/images/science2.jpg",
  project: "https://www.savraxaul.in/images/project.jpg",
  award2: "https://www.savraxaul.in/images/award.jpg",
  calendar: "https://www.savraxaul.in/images/calender.jpeg",
  student1: "https://www.savraxaul.in/images/dipanshu.jpeg",
  student2: "https://www.savraxaul.in/images/ratan.jpeg",
};

export const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Admissions", href: "#admissions" },
  { label: "Academics", href: "#academics" },
  { label: "Facilities", href: "#facilities" },
  { label: "Gallery", href: "#gallery" },
  { label: "Notices", href: "#notices" },
  { label: "Contact", href: "#contact" },
];

/** DOM order — used for scroll spy */
export const SECTION_IDS = [
  "home",
  "categories",
  "about",
  "leadership",
  "academics",
  "facilities",
  "achievements",
  "gallery",
  "notices",
  "admissions",
  "contact",
];

export const STATS = [
  { value: 10, suffix: "", label: "Class Levels", note: "Nursery → Class X" },
  { value: 2000, suffix: "+", label: "Happy Students", note: "Nurtured every day" },
  { value: 60, suffix: "+", label: "Expert Teachers", note: "Dedicated & caring" },
  { value: 100, suffix: "+", label: "Awards & Honours", note: "District & State Level" },
];

export const TICKER = [
  "Best School Award 2025-2026 — East Champaran District (Bihar)",
  "Admissions Open for Session 2026-27 — Nursery to Class X",
  "Smart classrooms • Science & Computer Labs • Green Campus",
  "Annual Day 2025 — a grand celebration of talent",
  "Parent-Teacher Meeting — Saturday, 10:00 AM",
];

export const CATEGORIES = [
  {
    num: "01",
    icon: "book",
    title: "About Us",
    desc: "Our story, mission, vision and what makes S.A.V. Raxaul's trusted school.",
    href: "#about",
    tone: "bg-royal-100 text-royal-700",
    img: IMG.building,
  },
  {
    num: "02",
    icon: "grad",
    title: "Leadership",
    desc: "Principal, Vice Principal and the Board of Directors.",
    href: "#leadership",
    tone: "bg-saffron-100 text-saffron-600",
    img: IMG.campus,
  },
  {
    num: "03",
    icon: "doc",
    title: "Admissions",
    desc: "A simple 5-step admission process for Nursery to Class X.",
    href: "#admissions",
    tone: "bg-leaf-100 text-leaf-600",
    img: IMG.calendar,
  },
  {
    num: "04",
    icon: "target",
    title: "Academics",
    desc: "Stages, classes, subjects and our activity-led teaching.",
    href: "#academics",
    tone: "bg-royal-100 text-royal-700",
    img: IMG.classroom,
  },
  {
    num: "05",
    icon: "building",
    title: "Facilities & Campus",
    desc: "Labs, library, smart classrooms, sports and daily amenities.",
    href: "#facilities",
    tone: "bg-saffron-100 text-saffron-600",
    img: IMG.lab,
  },
  {
    num: "06",
    icon: "trophy",
    title: "Our Achievements",
    desc: "Best School Award 2025-2026 and 100+ proud honours.",
    href: "#achievements",
    tone: "bg-gold-300/40 text-ink-800",
    img: IMG.award,
  },
  {
    num: "07",
    icon: "eye",
    title: "Gallery",
    desc: "Life at S.A.V. in pictures — campus, labs, events and more.",
    href: "#gallery",
    tone: "bg-leaf-100 text-leaf-600",
    img: IMG.green,
  },
  {
    num: "08",
    icon: "bell",
    title: "Notices",
    desc: "Latest announcements, holidays, events and academic updates.",
    href: "#notices",
    tone: "bg-royal-100 text-royal-700",
    img: IMG.reading,
  },
  {
    num: "09",
    icon: "phone",
    title: "Contact & Visit",
    desc: "Address, phone, email, office hours and enquiry form.",
    href: "#contact",
    tone: "bg-saffron-100 text-saffron-600",
    img: IMG.sports,
  },
];

export const ABOUT = {
  title: "Raxaul's Trusted School for Quality Education",
  p1: "Shantiniketan Adarsh Vidyalaya is proud to be one of Raxaul's most trusted schools, providing quality education in a safe and supportive environment. We focus on academic excellence, strong values, and overall student development.",
  p2: "Our experienced teachers guide students with dedication and modern teaching methods. With well-equipped classrooms and co-curricular activities, we ensure every child builds a strong foundation for success.",
  points: [
    "Experienced & dedicated teachers",
    "Value-based, character-first education",
    "Modern, activity-led teaching methods",
    "Safe, caring & supportive environment",
  ],
};

export const PRINCIPAL = {
  name: "Victor Deka",
  role: "Principal, S.A.V. Raxaul",
  slotId: "principal",
  initials: "VD",
  // Add the original image at this path to publish it for every visitor.
  img: "images/victor-deka.jpg",
  message:
    "Welcome to Shantiniketan Adarsh Vidyalaya. Our school is a place where students are encouraged to grow academically, socially, and morally. We aim to build confident learners with strong values, discipline, and a passion for lifelong learning.",
};

export const VP = {
  name: "Er. Kundan Raj",
  role: "Vice Principal, S.A.V. Raxaul",
  slotId: "vice-principal",
  initials: "KR",
  // Add the original image here to show it publicly on every device.
  img: "images/kundan-raj.jpg",
  message:
    "Education is not only about books, but also about building strong character and preparing students for the future.",
};

export const BOARD = [
  {
    name: "Simon Rex",
    role: "Chairman, Board of Directors",
    slotId: "board-simon-rex",
    initials: "SR",
    quote:
      "We believe education is the key to success and growth. Our mission is to provide balanced learning with knowledge and character.",
  },
  {
    name: "Arvind Kumar Singh",
    role: "Board Director",
    slotId: "board-arvind-singh",
    initials: "AK",
    quote:
      "Our goal is to nurture confident learners through discipline, creativity, and modern teaching practices.",
  },
  {
    name: "Ashok Kumar Singh",
    role: "Board Director",
    slotId: "board-ashok-singh",
    initials: "AS",
    quote:
      "We focus on building strong academic foundations along with honesty, respect, and life skills.",
  },
];

export const STAGES = [
  {
    stage: "Early Years",
    classes: "Nursery • LKG • UKG",
    age: "Age 3 – 5",
    icon: "sun",
    color: "saffron",
    desc: "Play-way learning through rhymes, stories, art and activity — building curiosity, motor skills and a joyful bond with school.",
    subjects: ["Play-way", "Rhymes & Stories", "Number Sense", "Motor Skills"],
  },
  {
    stage: "Primary School",
    classes: "Class I – V",
    age: "Age 6 – 10",
    icon: "book",
    color: "royal",
    desc: "Strong foundations in language, mathematics and general knowledge, taught with activity-based methods and regular follow-up.",
    subjects: ["English", "Mathematics", "EVS", "Hindi", "Art & Craft"],
  },
  {
    stage: "Middle School",
    classes: "Class VI – X",
    age: "Age 11 – 15",
    icon: "grad",
    color: "leaf",
    desc: "Concept-driven academics, hands-on lab work and structured board-exam preparation with personal mentorship for Class X.",
    subjects: ["Science", "Mathematics", "Social Science", "English", "Computer"],
  },
];

export const CLASSES = [
  "Nursery", "LKG", "UKG", "Class I", "Class II", "Class III", "Class IV", "Class V",
  "Class VI", "Class VII", "Class VIII", "Class IX", "Class X",
];

export const SUBJECTS = [
  { name: "English", icon: "pen" },
  { name: "Mathematics", icon: "grid" },
  { name: "Science", icon: "flask" },
  { name: "EVS", icon: "leaf" },
  { name: "Social Science", icon: "pin" },
  { name: "Hindi", icon: "doc" },
  { name: "Computer Science", icon: "monitor" },
  { name: "Physical Education", icon: "ball" },
  { name: "Moral Science", icon: "heart" },
  { name: "Art & Craft", icon: "palette" },
];

export const PEDAGOGY = [
  { icon: "monitor", title: "Smart & Interactive Teaching", text: "Visual, hands-on lessons that keep every child engaged." },
  { icon: "spark", title: "Activity-Based Learning", text: "Learning by doing — projects, experiments and games." },
  { icon: "target", title: "Regular Assessments", text: "Continuous evaluation to track and boost growth." },
  { icon: "users", title: "Parent-Teacher Meetings", text: "Regular PTMs — parents are true partners in learning." },
];

export const CAMPUS_CARDS = [
  {
    title: "Modern Infrastructure",
    text: "Spacious classrooms, strong buildings and a learning-friendly environment.",
    img: IMG.building,
    icon: "building",
  },
  {
    title: "Green & Peaceful Campus",
    text: "A clean and eco-friendly atmosphere for healthy student growth.",
    img: IMG.green,
    icon: "leaf",
  },
  {
    title: "Sports & Activities",
    text: "Daily physical training and co-curricular activities for all-round development.",
    img: IMG.sports,
    icon: "ball",
  },
];

export const FACILITIES = [
  {
    title: "Advanced Computer Lab",
    text: "Well-equipped lab for digital learning, coding and technology skills.",
    img: IMG.lab,
    icon: "monitor",
  },
  {
    title: "Library & Reading",
    text: "A peaceful, knowledge-rich space that builds reading habits and imagination.",
    img: IMG.reading,
    icon: "book",
  },
  {
    title: "Smart Classrooms",
    text: "Spacious classrooms with modern teaching tools for better learning.",
    img: IMG.classroom,
    icon: "spark",
  },
  {
    title: "Science & Innovation",
    text: "Practical science learning that encourages creativity and experimentation.",
    img: IMG.science,
    icon: "flask",
  },
  {
    title: "Student Projects",
    text: "Hands-on projects that enhance problem-solving and real-world learning.",
    img: IMG.project,
    icon: "pen",
  },
  {
    title: "Sports & Activity Areas",
    text: "Physical fitness and discipline — spaces designed for holistic growth.",
    img: IMG.sports,
    icon: "ball",
  },
];

export const AMENITIES = [
  { icon: "bus", title: "Safe School Transport" },
  { icon: "drop", title: "Clean Drinking Water" },
  { icon: "shield", title: "Safety & Security" },
  { icon: "sun", title: "Open Play Areas" },
  { icon: "music", title: "Music & Dance" },
  { icon: "heart", title: "First-Aid Care" },
];

export const ACHIEVEMENT_CARDS = [
  {
    icon: "medal",
    title: "Academic Excellence",
    text: "Consistently strong results and dedicated board-exam mentorship for Class X students.",
  },
  {
    icon: "trophy",
    title: "Sports Champions",
    text: "Our students compete with pride and shine in school games and district-level events.",
  },
  {
    icon: "star",
    title: "Annual Day & Events",
    text: "Cultural nights, annual day and festivals that give every talent a stage to shine.",
  },
  {
    icon: "heart",
    title: "Values & Community",
    text: "Discipline, social service and value education woven into everyday school life.",
  },
];

export const MOMENTS = [
  { img: IMG.award2, caption: "Award Moments" },
  { img: IMG.project, caption: "Project Work" },
  { img: IMG.science, caption: "Science Learning" },
  { img: IMG.sports, caption: "Sports & Games" },
];

// These two slots use the visitor-supplied classroom and campus group photographs.
// Add the originals to public/images to publish them for everyone.
export const FEATURED_GALLERY = [
  { id: "classroom-group", img: "images/gallery-classroom-group.jpg", caption: "Our Students in the Classroom" },
  { id: "campus-group", img: "images/gallery-campus-group.jpg", caption: "Students & Teacher on Campus" },
];

export const GALLERY = [
  { img: IMG.campus, caption: "Our Campus Building" },
  { img: IMG.classroom, caption: "Smart Classroom" },
  { img: IMG.lab, caption: "Computer Lab" },
  { img: IMG.building, caption: "Main School Block" },
  { img: IMG.reading, caption: "Library & Reading" },
  { img: IMG.sports, caption: "Sports & Activities" },
  { img: IMG.science, caption: "Science Learning" },
  { img: IMG.green, caption: "Green & Peaceful Campus" },
  { img: IMG.project, caption: "Student Projects" },
];

export const NOTICES = [
  {
    date: "02 Jan 2026",
    title: "Admissions Open 2026-27",
    text: "Admissions are now open for Nursery to Class X. Seats are limited — contact the school office today.",
    tag: "Admissions",
    pinned: true,
  },
  {
    date: "15 Dec 2025",
    title: "Best School Award 2025-2026",
    text: "S.A.V. Raxaul is honoured with the Best School Award for excellence in education — East Champaran District (Bihar).",
    tag: "Award",
    pinned: false,
  },
  {
    date: "28 Dec 2025",
    title: "Winter Vacation",
    text: "The school remains closed for winter break from 30 Dec to 4 Jan. Practice sheets will be shared with all classes.",
    tag: "Holiday",
    pinned: false,
  },
  {
    date: "12 Nov 2025",
    title: "Parent-Teacher Meeting",
    text: "PTM for all classes will be held on Saturday, 10:00 AM – 1:00 PM, in the respective classrooms.",
    tag: "Event",
    pinned: false,
  },
  {
    date: "20 Oct 2025",
    title: "Annual Day 2025",
    text: "Our Annual Day was a grand celebration of music, dance and drama performed by our students.",
    tag: "Event",
    pinned: false,
  },
  {
    date: "05 Sep 2025",
    title: "Olympiad Registrations",
    text: "Registrations are open for Mathematics and Science Olympiads for Classes III to X.",
    tag: "Academics",
    pinned: false,
  },
];

export const STEPS = [
  { icon: "phone", title: "Enquiry", text: "Visit the campus or call our office to begin." },
  { icon: "doc", title: "Application Form", text: "Submit a simple admission application." },
  { icon: "users", title: "Interaction", text: "A friendly, easy assessment of the child." },
  { icon: "check", title: "Document Check", text: "Verification of the required documents." },
  { icon: "grad", title: "Enrollment", text: "Complete fees & welcome to the S.A.V. family!" },
];

export const ELIGIBILITY = [
  { cls: "Nursery", age: "3 years + (as on 1 Apr)" },
  { cls: "LKG", age: "4 years + (as on 1 Apr)" },
  { cls: "UKG", age: "5 years + (as on 1 Apr)" },
  { cls: "Class I", age: "6 years + (as on 1 Apr)" },
  { cls: "Class II – X", age: "As per standard eligibility" },
];

export const DOCS = [
  "Birth Certificate",
  "Aadhaar Card (child)",
  "Transfer Certificate",
  "4 passport-size photos of the child",
  "2 passport-size photos of each parent/guardian",
  "Parent/Guardian ID",
];

export const CONTACT_INFO = {
  address: "Main Road, Laxmipur, Raxaul - 845305, Bihar",
  phones: ["+91 94306 82924", "+91 87895 70326"],
  email: "shantiniketanadarshvidyalaya@gmail.com",
  hours: "Monday – Saturday, 8:00 AM – 2:00 PM",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=Shantiniketan+Adarsh+Vidyalaya+Raxaul+Bihar",
};

export const TESTIMONIALS = [
  {
    name: "Dipanshu Singh",
    img: IMG.student1,
    text: "I enjoy learning here with modern facilities, friendly teachers and activities that make school life exciting.",
  },
  {
    name: "Ratan Kumar",
    img: IMG.student2,
    text: "I love studying in this school because of the supportive teachers, advanced classrooms and fun activities that make learning enjoyable.",
  },
];
