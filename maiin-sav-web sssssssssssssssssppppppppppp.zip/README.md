# Shantiniketan Adarsh Vidyalaya Website

React + Vite website with a server-side admissions enquiry endpoint. The previous enquiry form only showed a thank-you message; it did not send or store anything. This version never reports success until the delivery providers accept the requests.

## Admissions enquiries

The form sends the student's name, parent/guardian's name and phone, optional email and message, and selected class to:

- Email: `shantiniketanadarshvidyalaya@gmail.com` via Resend.
- SMS: `+91 94306 82924`, `+91 87895 70326`, and `+91 8002162800` via Twilio.

The server function is at `netlify/functions/enquiry.mjs`. It does **not** store enquiry details on the website or in a database. Resend and Twilio process the data to deliver notifications. The form accepts user consent before sending. SMS acceptance from Twilio means queued/accepted by Twilio, **not** confirmed delivery to a phone; check the Twilio dashboard for final delivery status. The form reports partial success honestly if any destination fails. Do not blindly resubmit a partial enquiry because duplicate notifications can occur.

## Setup before live enquiries work

Deploy this project to **Netlify** using the included `netlify.toml`. In the Netlify site's Environment variables, set:

| Variable | Value |
| --- | --- |
| `RESEND_API_KEY` | A Resend API key allowed to send email. |
| `ENQUIRY_FROM_EMAIL` | A sending address on a domain verified in Resend, e.g. `enquiries@your-verified-domain.com`. This is **not** the school Gmail inbox. |
| `TWILIO_ACCOUNT_SID` | Twilio Account SID. |
| `TWILIO_AUTH_TOKEN` | Twilio Auth Token. |
| `TWILIO_MESSAGING_SERVICE_SID` | A Messaging Service containing an SMS sender able to deliver to India. Set this **or** `TWILIO_FROM_NUMBER`. |
| `TWILIO_FROM_NUMBER` | Alternative registered sender number (E.164 format) if not using a Messaging Service. |

Verify the Resend sending domain and enable the Twilio account/geo permissions/credits. For SMS to India, use an approved international sending route or finish the DLT registration required for a domestic route; check Twilio's India guidelines for your account and sender. Long enquiry texts may be billed as multiple SMS segments. Then redeploy the Netlify site. **Never put API keys in `src/`, `index.html`, or a `VITE_` environment variable.** The recipient email and SMS numbers are fixed server-side, not supplied by visitors. The Netlify function has a per-IP rate limit of five requests per minute, a honeypot, request-size limits, validation, and a same-origin check; consider an additional CAPTCHA if the site receives spam.

If Netlify or the provider credentials are absent, the form shows an explicit error with the school phone number and does not claim the enquiry was sent. `npm run dev` alone serves only the Vite frontend, not the Netlify function. Use Netlify Dev to exercise the complete flow locally, or test it on a deployed Netlify site with real credentials. Provider delivery cannot be tested by a production build alone.

## Admission documents

The admissions section lists four passport-size photos of the child and **two passport-size photos of each parent/guardian** alongside the other required documents.

## Gallery images and scrolling

The Gallery and Leadership have no login or passcode. The gallery has two dedicated positions for the classroom group photo and the outdoor group photo. Chat image previews are not present as image files in the project. The images appear publicly once `gallery-classroom-group.jpg` and `gallery-campus-group.jpg` are added to `public/images/` and the site is redeployed. Anyone can use the Gallery's optional file picker for a local preview, but those uploads are stored **only in that browser**, not on the website server.

The Leadership portraits are also public image slots. To show the actual supplied portraits to everyone, add `public/images/victor-deka.jpg` and `public/images/kundan-raj.jpg` and redeploy. Without the real photo files, initials appear rather than an AI-generated substitute. Previously saved browser-only portraits are used only on that device if a public image is unavailable.

To keep scrolling responsive, each section's reveal runs only once as it enters the viewport, using IntersectionObserver and opacity/transform transitions (shorter on touch screens, off for reduced-motion users). In-page links, including Explore options, scroll smoothly and replay a one-time arrival reveal on the destination heading. There is no per-frame scroll handler. Continuous ticker, badge, and bubble animations stay disabled. Photos continue to load lazily, the gallery uses a stable grid rather than a masonry column reflow, and the announcements can be scrolled sideways by hand.