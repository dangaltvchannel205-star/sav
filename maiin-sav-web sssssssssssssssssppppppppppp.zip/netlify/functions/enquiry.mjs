// This function runs on Netlify, not in the visitor's browser. Keep API keys in Netlify environment variables.
const SCHOOL_EMAIL = "shantiniketanadarshvidyalaya@gmail.com";
const SCHOOL_PHONES = ["+919430682924", "+918789570326", "+918002162800"];
const CLASSES = new Set([
  "Nursery", "LKG", "UKG", "Class I", "Class II", "Class III", "Class IV",
  "Class V", "Class VI", "Class VII", "Class VIII", "Class IX", "Class X",
]);

export const config = {
  path: "/api/enquiry",
  rateLimit: { windowLimit: 5, windowSize: 60, aggregateBy: ["ip", "domain"] },
};

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });

const clean = (value, max, multiline = false) => {
  if (typeof value !== "string" || value.length > max) return null;
  const forbidden = multiline ? /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g : /[\u0000-\u001f\u007f]/g;
  return value.replace(forbidden, " ").trim();
};

const normalisePhone = (value) => {
  if (typeof value !== "string" || value.length > 24 || !/^[\d+().\s-]+$/.test(value)) return null;
  const digits = value.replace(/\D/g, "");
  const local = digits.length === 12 && digits.startsWith("91") ? digits.slice(2)
    : digits.length === 11 && digits.startsWith("0") ? digits.slice(1) : digits;
  return /^[6-9]\d{9}$/.test(local) ? `+91${local}` : null;
};

async function sendEmail(text, replyTo, reference) {
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      "Content-Type": "application/json",
      "Idempotency-Key": `sav-enquiry-${reference}`,
    },
    body: JSON.stringify({
      from: `S.A.V. Enquiries <${process.env.ENQUIRY_FROM_EMAIL}>`,
      to: [SCHOOL_EMAIL],
      subject: `New admission enquiry - ${reference}`,
      text,
      ...(replyTo ? { reply_to: replyTo } : {}),
    }),
    signal: AbortSignal.timeout(12000),
  });
  if (!response.ok) throw new Error(`Email provider returned ${response.status}`);
  const result = await response.json();
  if (!result.id) throw new Error("Email provider did not confirm the request");
}

async function sendSms(to, body) {
  const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_MESSAGING_SERVICE_SID, TWILIO_FROM_NUMBER } = process.env;
  const params = new URLSearchParams({ To: to, Body: body });
  if (TWILIO_MESSAGING_SERVICE_SID) params.set("MessagingServiceSid", TWILIO_MESSAGING_SERVICE_SID);
  else params.set("From", TWILIO_FROM_NUMBER);

  const response = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(TWILIO_ACCOUNT_SID)}/Messages.json`,
    {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`).toString("base64")}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params,
      signal: AbortSignal.timeout(12000),
    }
  );
  if (!response.ok) throw new Error(`SMS provider returned ${response.status}`);
  const result = await response.json();
  if (!result.sid || ["failed", "undelivered"].includes(result.status)) {
    throw new Error("SMS provider did not accept the message");
  }
}

export default async function enquiry(request) {
  if (request.method !== "POST") return json({ error: "Use POST to submit an enquiry." }, 405);

  const origin = request.headers.get("origin");
  if (origin) {
    try {
      if (new URL(origin).host !== new URL(request.url).host) {
        return json({ error: "Cross-site submissions are not allowed." }, 403);
      }
    } catch {
      return json({ error: "Invalid origin." }, 403);
    }
  }

  if (!request.headers.get("content-type")?.includes("application/json")) {
    return json({ error: "Please submit the form as JSON." }, 415);
  }
  if (Number(request.headers.get("content-length") || 0) > 8000) {
    return json({ error: "The enquiry is too long." }, 413);
  }

  let input;
  try {
    const raw = await request.text();
    if (raw.length > 8000) return json({ error: "The enquiry is too long." }, 413);
    input = JSON.parse(raw);
    if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error("Invalid body");
  } catch {
    return json({ error: "Invalid enquiry details. Please check the form." }, 400);
  }

  // Honeypot and validation run before any paid email/SMS provider is called.
  if (input.website) return json({ error: "Unable to process this enquiry." }, 400);
  const studentName = clean(input.studentName, 80);
  const guardianName = clean(input.guardianName, 80);
  const guardianPhone = normalisePhone(input.guardianPhone);
  const applyingFor = clean(input.applyingFor, 20);
  const email = clean(input.email || "", 254);
  const message = clean(input.message || "", 600, true);

  if (!studentName || !guardianName || !guardianPhone || !CLASSES.has(applyingFor)
      || email === null || message === null || input.consent !== true) {
    return json({ error: "Please provide the student name, guardian name, valid Indian phone number, class, and consent." }, 400);
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return json({ error: "Please enter a valid email address." }, 400);
  }

  const { RESEND_API_KEY, ENQUIRY_FROM_EMAIL, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN,
    TWILIO_FROM_NUMBER, TWILIO_MESSAGING_SERVICE_SID } = process.env;
  if (!RESEND_API_KEY || !ENQUIRY_FROM_EMAIL || !TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN
      || (!TWILIO_FROM_NUMBER && !TWILIO_MESSAGING_SERVICE_SID)) {
    return json({ error: "Online enquiries are not configured yet. No details were sent. Please call the school office." }, 503);
  }

  const reference = crypto.randomUUID();
  const time = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" });
  const details = [
    `New S.A.V. admission enquiry (${reference})`,
    `Received (IST): ${time}`,
    `Student: ${studentName}`,
    `Parent / guardian: ${guardianName}`,
    `Parent phone: ${guardianPhone}`,
    `Parent email: ${email || "Not provided"}`,
    `Applying for: ${applyingFor}`,
    `Message: ${message || "No additional message"}`,
  ];
  const emailBody = details.join("\n");
  const smsBody = details.join("\n");

  const results = await Promise.allSettled([
    sendEmail(emailBody, email, reference),
    ...SCHOOL_PHONES.map((number) => sendSms(number, smsBody)),
  ]);

  const emailAccepted = results[0].status === "fulfilled";
  const smsAccepted = SCHOOL_PHONES.filter((_, index) => results[index + 1].status === "fulfilled");
  const smsFailed = SCHOOL_PHONES.filter((_, index) => results[index + 1].status !== "fulfilled");
  const success = emailAccepted && smsFailed.length === 0;
  const partial = !success && (emailAccepted || smsAccepted.length > 0);

  if (!success) {
    // Log only provider errors; never log the student's personal information or message.
    console.error("Enquiry notification failure", reference, results.map((result) =>
      result.status === "rejected" ? String(result.reason) : "accepted"));
  }

  return json({
    success,
    partial,
    reference,
    emailAccepted,
    smsAccepted,
    smsFailed,
    message: success
      ? "The email and all three SMS notifications were accepted by their providers. The school will contact you soon."
      : partial
        ? "We could not confirm all notifications. Please call the school office to confirm your enquiry. Do not resubmit automatically."
        : "No notification could be confirmed. Please call the school office before trying again.",
  }, success ? 200 : partial ? 207 : 502);
}