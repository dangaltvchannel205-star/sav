Leadership portraits
====================

The website shows images from this directory to every visitor.

- Save the original Victor Deka photo as `victor-deka.jpg` in this directory.
- Save the original Er. Kundan Raj photo as `kundan-raj.jpg` in this directory.
- Redeploy the website. Both portraits will then be visible to every visitor in Leadership, without a login.

Do not use AI-generated stand-ins for these portraits. If a photo is missing,
the website shows that person's initials instead. Photos previously uploaded
into a browser remain visible only on that browser as a fallback.

Gallery photographs
===================

The gallery has two dedicated slots for the exact photos sent in chat (the
classroom group and the group with a teacher outdoors). This environment does
not receive chat previews as image files. To make them visible to all visitors:

- Save the classroom group photo as `gallery-classroom-group.jpg` here.
- Save the outdoor group photo as `gallery-campus-group.jpg` here.
- Redeploy the site. The gallery automatically detects these files.

The gallery itself has no lock or passcode. A visitor can preview either photo
on their own device with the optional Gallery file picker. Browser-only
previews are not published to other visitors.